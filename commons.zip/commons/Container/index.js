import styled from 'styled-components/native';
import { Box } from '@components/commons';

const Container = styled(Box)`
  padding: 32px;
`;

export const ListContainer = styled(Box)`
  padding-left: 32;
  padding-right: 32;
`;

export const ListItemContainer = styled(Box)`
  padding-top: 24;
  padding-bottom: 24;
`;

export default Container;
