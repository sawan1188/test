import React from 'react';
import { Text } from '@components/commons';
import VersionNumber from 'react-native-version-number';
import Config from 'react-native-config';
import { useIntl } from '@components/commons/hooks';

export const AppVersion = () => {
  const intl = useIntl();
  const displayAppVersion = `${VersionNumber.appVersion} (${VersionNumber.buildVersion})`;
  const displayContent =
    !Config.ENVIRONMENT || Config.ENVIRONMENT.toUpperCase() === 'PRODUCTION'
      ? displayAppVersion
      : `${displayAppVersion} [${Config.ENVIRONMENT.toUpperCase()}]`;

  return (
    <Text>
      {intl.formatMessage({ id: 'appversion' })} {displayContent}
    </Text>
  );
};
