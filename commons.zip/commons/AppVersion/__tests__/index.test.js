import React from 'react';
import VersionNumber from 'react-native-version-number';
import Config from 'react-native-config';
import { render } from '@testUtils';
import { AppVersion } from '../';
import { Text } from 'react-native';

describe('AppVersion', () => {
  let originalAppVersion;
  let originalBuildVersion;
  beforeAll(() => {
    originalAppVersion = VersionNumber.appVersion;
    originalBuildVersion = VersionNumber.buildVersion;
  });
  afterAll(() => {
    VersionNumber.appVersion = originalAppVersion;
    VersionNumber.buildVersion = originalBuildVersion;
  });
  it('should render text', () => {
    let [component] = render(<AppVersion />);

    expect(component.queryAllByType(Text).length).toEqual(1);
  });

  it('should render app version', () => {
    VersionNumber.appVersion = '1.2.1';
    VersionNumber.buildVersion = '56';
    Config.ENVIRONMENT = null;

    let [component] = render(<AppVersion />);
    expect(component.getByText('App version 1.2.1 (56)')).toBeDefined();
  });

  it('should render environment if environment is not production', () => {
    VersionNumber.appVersion = '1.2.1';
    VersionNumber.buildVersion = '56';
    Config.ENVIRONMENT = 'UAT';
    let [component] = render(<AppVersion />);

    expect(component.getByText('App version 1.2.1 (56) [UAT]')).toBeDefined();
  });

  it('should not render environment if environment is production', () => {
    VersionNumber.appVersion = '1.2.1';
    VersionNumber.buildVersion = '56';
    Config.ENVIRONMENT = 'production';
    let [component] = render(<AppVersion />);

    expect(component.getByText('App version 1.2.1 (56)')).toBeDefined();
  });
});
