import React from 'react';
import {
  fontFamily,
  textAlign,
  lineHeight,
  fontWeight,
  fontSize,
  letterSpacing,
  color,
  space,
  fontStyle,
  marginTop,
  paddingTop,
  paddingBottom,
  flexWrap,
  width,
  marginRight,
  marginLeft,
} from 'styled-system';
import styled from 'styled-components/native';

const Text = styled.Text`
    ${fontSize}
    ${fontFamily}
    ${textAlign}
    ${lineHeight}
    ${fontWeight}
    ${letterSpacing}
    ${color}
    ${space}
    ${fontStyle}
    ${marginRight}
    ${marginLeft}
    ${marginTop}
    ${paddingTop}
    ${paddingBottom}
    ${flexWrap}
    ${width}
`;

Text.defaultProps = {
  fontFamily: 'default',
  fontSize: 16,
  color: 'gray.1',
  lineHeight: 22,
};

const SectionHeadingText = props => (
  <Text fontWeight="bold" color="gray.0" {...props} />
);

const SecondaryText = props => <Text color="gray.3" {...props} />;

const ScreenHeadingText = props => (
  <Text
    fontWeight="light"
    color="gray.0"
    fontSize={26}
    lineHeight={37}
    letterSpacing={-1.5}
    {...props}
  />
);

const PlainText = props => (
  <Text
    color="gray.1"
    fontSize={16}
    lineHeight={22}
    letterSpacing={0.3}
    {...props}
  />
);

const ErrorText = props => (
  <Text
    color="gray.8"
    fontSize={14}
    lineHeight={22}
    letterSpacing={0.3}
    {...props}
  />
);

export {
  ScreenHeadingText,
  SectionHeadingText,
  SecondaryText,
  PlainText,
  ErrorText,
};
export default Text;
