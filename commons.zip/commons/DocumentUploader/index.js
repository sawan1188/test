import React from 'react';
import PropTypes from 'prop-types';
import { Box, UploadBox, Flex, SectionHeadingText } from '@components/commons';
import { Animated } from 'react-native';
import { withScrollBar } from '../Carousel';

const DocumentUploader = ({
  accessibilityDocumentType,
  accessibilityField,
  title,
  size,
  onAdd,
  onView,
  data,
  disabled,
  onContentSizeChange,
  onScroll,
  onLayout,
}) => (
  <>
    {title && (
      <Box px={4} pt={2} pb={2}>
        <SectionHeadingText>{title}</SectionHeadingText>
      </Box>
    )}
    <Animated.ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      onContentSizeChange={onContentSizeChange}
      onScroll={onScroll}
      onLayout={onLayout}
    >
      <Flex flexDirection="row" flexWrap="nowrap" pr={4}>
        {[...Array(size).keys()].map(i => {
          let component;
          const commonProps = {
            accessibilityDocumentType,
            accessibilityField,
          };
          if (i === data.length) {
            component = (
              <UploadBox
                disabled={disabled}
                onAdd={() => onAdd(i)}
                {...commonProps}
              />
            );
          } else if (i < data.length) {
            component = (
              <UploadBox
                data={data[i]}
                onView={() => onView(i)}
                {...commonProps}
              />
            );
          } else {
            component = <UploadBox {...commonProps} />;
          }

          return (
            <Box key={i} m={2} ml={i === 0 ? 4 : 2}>
              {component}
            </Box>
          );
        })}
      </Flex>
    </Animated.ScrollView>
  </>
);

DocumentUploader.propTypes = {
  title: PropTypes.string,
  size: PropTypes.number,
  theme: PropTypes.shape({}),
  onAdd: PropTypes.func,
  onView: PropTypes.func,
  disabled: PropTypes.bool,
  data: PropTypes.arrayOf(
    PropTypes.shape({ uri: PropTypes.string, type: PropTypes.string }),
  ),
  accessibilityDocumentType: PropTypes.string.isRequired,
  accessibilityField: PropTypes.string.isRequired,
};

export default DocumentUploader;

export const DocumentUploaderWithScrollBar = withScrollBar(DocumentUploader);
