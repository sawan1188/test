import { renderForTest } from '@testUtils';
import React from 'react';

import DocumentUploader from '../index';
import UploadBox from '@components/commons/UploadBox';

describe('DocumentUploader', () => {
  it('should render uploadbox', () => {
    const component = renderForTest(<DocumentUploader data={[0]} size={1} />);
    expect(component.queryAllByType(UploadBox).length).toBe(1);
  });

  it('should render 2 UploadBox', () => {
    const component = renderForTest(<DocumentUploader data={[0]} size={2} />);
    expect(component.queryAllByType(UploadBox).length).toBe(2);
  });
});
