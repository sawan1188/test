import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'react-native-elements';
import { useTheme } from '@components/commons/hooks';

const StyledIcon = ({ variant, ...props }) => {
  const theme = useTheme();
  const color = {
    default: theme.colors.gray[3],
    darkGray: theme.colors.gray[1],
    success: theme.colors.success[0],
    error: theme.colors.error[0],
  }[variant];

  return <Icon color={color} {...props} />;
};

StyledIcon.defaultProps = {
  variant: 'default',
  size: 24,
};

StyledIcon.propTypes = {
  variant: PropTypes.string,
  size: PropTypes.number,
};

export default StyledIcon;
