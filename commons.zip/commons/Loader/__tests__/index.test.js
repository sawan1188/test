import { renderForTest } from '@testUtils';
import React from 'react';
import { Loader } from '@components/commons';

jest.useFakeTimers();

describe('Loader', () => {
  it('renders primary loader correctly', () => {
    const primaryLoader = renderForTest(<Loader primary />).toJSON();
    // expect(primaryLoader).toMatchSnapshot();
  });

  it('renders secondary loader correctly', () => {
    const secondaryLoader = renderForTest(
      <Loader loadingText="loading" />,
    ).toJSON();
    // expect(secondaryLoader).toMatchSnapshot();
  });
});
