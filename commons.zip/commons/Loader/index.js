import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Modal } from 'react-native';
import { Text } from '@components/commons';
import theme from '@theme';
import AnimatedEllipsis from 'react-native-animated-ellipsis';

const styles = StyleSheet.create({
  viewStyle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loader: {
    fontSize: theme.fontSizes[9],
    letterSpacing: -20,
    marginTop: -20,
    color: theme.colors.gray[3],
  },
  loadingText: {
    fontSize: theme.fontSizes[2],
    color: theme.colors.gray[1],
  },
});

const renderLoader = (loadingText, props) => {
  return (
    <View style={styles.viewStyle}>
      <AnimatedEllipsis
        minOpacity={0.4}
        animationDelay={200}
        style={styles.loader}
      />
      {loadingText && (
        <Text textAlign={props.textAlign ?? 'left'} style={styles.loadingText}>
          {loadingText}
        </Text>
      )}
    </View>
  );
};

const renderFullScreenLoader = loadingText => {
  return (
    <Modal>
      <View style={styles.viewStyle}>
        <AnimatedEllipsis
          minOpacity={0.4}
          animationDelay={200}
          style={styles.loader}
        />
        <Text style={styles.loadingText}>{loadingText}</Text>
      </View>
    </Modal>
  );
};

const Loader = ({ primary, ...props }) =>
  primary
    ? renderLoader(props.loadingText, props)
    : renderFullScreenLoader(props.loadingText);

Loader.propTypes = {
  primary: PropTypes.bool,
  loadingText: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
};

export default Loader;
