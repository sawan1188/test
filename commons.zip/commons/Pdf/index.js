/* istanbul ignore file */
import React, { useState, useEffect } from 'react';
import api from '@services/api';
import BasePdf from 'react-native-pdf';

const Pdf = React.forwardRef(({ secure, source, ...props }, ref) => {
  const [authHeaders, setAuthHeaders] = useState(null);
  useEffect(() => {
    async function fetchHeaders() {
      let authHeaders = await api.getAuthHeaders();
      setAuthHeaders(authHeaders);
    }
    fetchHeaders();
  }, []);

  const pdfSource = secure
    ? authHeaders
      ? {
          ...source,
          headers: authHeaders,
        }
      : null
    : source;

  return pdfSource ? <BasePdf ref={ref} source={pdfSource} {...props} /> : null;
});

export default Pdf;
