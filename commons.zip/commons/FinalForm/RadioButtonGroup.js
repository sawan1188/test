import React, { useState } from 'react';
import { Box } from '@components/commons';
import { useIntl } from '@components/commons/hooks';
import { injectIntl } from 'react-intl';
import styled, { withTheme } from 'styled-components/native';
import RadioButtonField from './RadioButtonField';

const RadioButtonGroup = props => {
  const { name, hint, options, errorTextComponent } = props;
  const intl = useIntl();
  const [error, setError] = useState(null);
  const [touched, setTouched] = useState(false);

  const ErrorText = styled.Text`
    position: absolute;
    top: 35;
    left: 0;
    font-size: 12px;
    ${({ theme }) => `
  color: ${theme.colors.error[0]}
`};
  `;

  const HintText = styled.Text`
    margin: 4px;
    position: relative;
    left: 16;
    font-size: 12px;
    ${({ theme }) => {
      return `color: ${theme.colors.gray[1]}`;
    }}
  `;

  const ErrorTextCom = errorTextComponent || ErrorText;

  return (
    <Box flex={1} mb={30}>
      <Box flex={1} flexDirection={'row'}>
        {options.map((option, index) => {
          return (
            <Box flex={1} key={`${name}-${index}`}>
              <RadioButtonField
                index={index}
                type="radio"
                option={option}
                value={option.defaultLabel}
                onError={setError}
                onTouch={setTouched}
                {...props}
              />
            </Box>
          );
        })}
      </Box>
      {error && touched ? (
        <ErrorTextCom>{intl.formatMessage({ id: error })}</ErrorTextCom>
      ) : (
        hint && <HintText>{hint}</HintText>
      )}
    </Box>
  );
};

export default injectIntl(withTheme(RadioButtonGroup));
