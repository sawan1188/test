import React from 'react';
import { Box, InputLabel } from '@components/commons';
import RadioButtonGroup from './RadioButtonGroup';
import { useIntl } from '@components/commons/hooks';
import { validateRequiredWithMessageId } from '@components/commons/validations';
import PropTypes from 'prop-types';
import { withTheme } from 'styled-components/native';

const GenderRadio = React.forwardRef(
  (
    {
      field,
      space,
      onNext,
      radioComponent,
      checkComponent,
      errorTextComponent,
    },
    ref,
  ) => {
    const genderOption = [
      { defaultLabel: 'Male', i18nId: 'picker.male' },
      { defaultLabel: 'Female', i18nId: 'picker.female' },
    ];
    const intl = useIntl();
    const getValidation = field => {
      const messageId = field.error?.i18nId || null;
      return value => validateRequiredWithMessageId({ value, messageId });
    };

    return (
      <Box height={100}>
        <InputLabel required={field.required}>
          {intl.formatMessage({
            id: field.i18nId,
            defaultMessage: field.defaultLabel,
          })}
        </InputLabel>
        <Box mt={25} flex={1}>
          <RadioButtonGroup
            options={genderOption}
            validate={field.required ? getValidation(field) : () => {}}
            name={field.id}
            hint={field.hint}
            onSelect={() => {
              onNext && onNext();
            }}
            radioComponent={radioComponent}
            checkComponent={checkComponent}
            errorTextComponent={errorTextComponent}
          />
        </Box>
      </Box>
    );
  },
);

GenderRadio.propTypes = {
  field: PropTypes.shape({
    i18nId: PropTypes.string.isRequired,
    defaultLabel: PropTypes.string,
    type: PropTypes.string.isRequired,
    required: PropTypes.bool,
    visible: PropTypes.bool,
    defaultValue: PropTypes.string,
  }).isRequired,
  space: PropTypes.number,
};

export default withTheme(GenderRadio);
