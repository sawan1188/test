import React from 'react';
import {
  Datepicker as CommonDatePicker,
  Image,
  Box,
} from '@components/commons';

import { useIntl } from '@components/commons/hooks';
import { SelectField } from '@components/commons/FinalForm';
import {
  validateRequiredWithMessageId,
  validateAgeWithMessageId,
} from '@components/commons/validations';
import { getFormattedDate } from '@utils';
import calendar from './images/calendar.png';
import PropTypes from 'prop-types';

const applyFormat = getFormattedDate.setFormat('DD MMM YYYY');

const DatePicker = React.forwardRef(
  (
    {
      mutators,
      field,
      space,
      onNext,
      selectFieldComponent,
      icImage = calendar,
      rightIconComponent,
    },
    ref,
  ) => {
    const intl = useIntl();
    const datePickerRef = React.useRef({ setIsVisile: null });

    const getValidation = field => {
      const messageId = field.error?.i18nId || null;
      return value => {
        return (
          validateRequiredWithMessageId({ value, messageId }) ||
          validateAgeWithMessageId({
            value,
            minAge: field.validation?.minAge || 16,
          })
        );
      };
    };

    React.useImperativeHandle(ref, () => ({
      focus: () =>
        datePickerRef.current.setIsVisile &&
        datePickerRef.current.setIsVisile(true),
    }));

    const datePickerName = field.id + 'ForView';
    const SelectFieldCom = selectFieldComponent || SelectField;
    const rightIconCom = rightIconComponent || (
      <Image source={icImage} size={25} />
    );

    return (
      <CommonDatePicker
        mutators={mutators}
        maximumDate={new Date()}
        type={field.type}
        onConfirm={date => {
          mutators.changeValue(field.id, date.toISOString());
          mutators.changeValue(datePickerName, applyFormat(date));

          setTimeout(() => {
            onNext && onNext();
          }, 400);
        }}
        field={({ setIsVisible }) => {
          if (!datePickerRef.current.setIsVisile)
            datePickerRef.current.setIsVisile = setIsVisible;
          return (
            <Box mt={space}>
              <SelectFieldCom
                required={field && field.required}
                type={'Date'}
                name={datePickerName}
                label={intl.formatMessage({
                  id: field.i18nId,
                  defaultMessage: field.defaultLabel,
                })}
                validate={field.required ? getValidation(field) : () => {}}
                onPress={() => setIsVisible(true)}
                onRight={() => rightIconCom}
                extraErrorData={{ minAge: field.validation?.minAge || 16 }}
                placeholder={
                  field &&
                  intl.formatMessage({
                    id: field.i18nId && `${field.i18nId}.placeholder`,
                    defaultMessage: field.defaultLabel,
                  })
                }
              />
            </Box>
          );
        }}
      />
    );
  },
);

DatePicker.propTypes = {
  field: PropTypes.shape({
    i18nId: PropTypes.string.isRequired,
    defaultLabel: PropTypes.string,
    type: PropTypes.string.isRequired,
    required: PropTypes.bool,
    visible: PropTypes.bool,
    defaultValue: PropTypes.string,
  }).isRequired,
  mutators: PropTypes.shape({
    changeValue: PropTypes.func,
  }),
  space: PropTypes.number,
};

export default DatePicker;
