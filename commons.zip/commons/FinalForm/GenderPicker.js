import React, { useImperativeHandle } from 'react';

import { Box } from '@components/commons';
import { SelectField } from '@components/commons/FinalForm';
import ModalPicker from '@components/commons/ModalPicker';
import { useIntl } from '@components/commons/hooks';

import { validateRequiredWithMessageId } from '@components/commons/validations';
import PropTypes from 'prop-types';

const GenderPicker = React.forwardRef(
  ({ field, mutators, space, onNext }, ref) => {
    const genderOption = [
      { defaultLabel: 'Male', i18nId: 'picker.male' },
      { defaultLabel: 'Female', i18nId: 'picker.female' },
    ];
    const genderRef = React.useRef({ setIsVisible: null });
    const intl = useIntl();
    const getValidation = field => {
      const messageId = field.error?.i18nId || null;
      return value => validateRequiredWithMessageId({ value, messageId });
    };
    useImperativeHandle(ref, () => ({
      focus: () => {
        genderRef.current?.setIsVisible && genderRef.current.setIsVisible(true);
      },
    }));
    return (
      <Box mt={space}>
        <ModalPicker
          options={genderOption}
          onConfirm={item => {
            mutators.changeValue(
              field.id,
              item
                ? intl.formatMessage({
                    id: item.i18nId,
                    defaultMessage: field.defaultLabel,
                  })
                : '',
            );
            onNext && onNext();
          }}
          field={({ setIsVisible }) => {
            if (!genderRef?.current?.setIsVisible)
              genderRef.current.setIsVisible = setIsVisible;
            return (
              <SelectField
                type={field.type}
                name={field.id}
                label={intl.formatMessage({
                  id: field.i18nId,
                  defaultMessage: field.defaultLabel,
                })}
                validate={field.required ? getValidation(field) : () => {}}
                onPress={() => setIsVisible && setIsVisible(true)}
              />
            );
          }}
        />
      </Box>
    );
  },
);

GenderPicker.propTypes = {
  field: PropTypes.shape({
    i18nId: PropTypes.string.isRequired,
    defaultLabel: PropTypes.string,
    type: PropTypes.string.isRequired,
    required: PropTypes.bool,
    visible: PropTypes.bool,
    defaultValue: PropTypes.string,
  }).isRequired,
  mutators: PropTypes.shape({
    changeValue: PropTypes.func,
  }),
  space: PropTypes.number,
};

export default GenderPicker;
