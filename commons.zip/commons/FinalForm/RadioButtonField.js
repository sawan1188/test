import React, { useEffect } from 'react';
import { Icon } from 'react-native-elements';
import { Box, Text } from '@components/commons';
import { useIntl } from '@components/commons/hooks';
import { TouchableOpacity } from 'react-native';
import styled from 'styled-components/native';
import { Field } from 'react-final-form';
import { runValidations } from '../utils';

const Radio = styled(Box)`
  height: 30px;
  width: 30px;
  margin-right: 10px;
  border-width: 2px;
  border-radius: 15px;
  border-color: #666666;
  ${({ checked }) => {
    return (
      checked &&
      `
        border-color:  #00847F;
        background-color: #00847F;
      `
    );
  }};

  ${({ touched, error }) => {
    return (
      touched &&
      error &&
      `
        border-color:  #E00000;
      `
    );
  }};
`;

const RadioButton = props => {
  const {
    input: { value, checked },
    name,
    disabled,
    option,
    onError,
    onTouch,
    onPress,
    index,
    meta: { error, touched },
    radioComponent,
    checkComponent,
  } = props;

  const intl = useIntl();

  useEffect(() => {
    onError(error);
  }, [error, onError]);

  useEffect(() => {
    onTouch(touched);
  }, [touched, onTouch]);

  const Checked = () => <Icon name="check" size={15} color="#FFF" />;

  const RadioCom = radioComponent || Radio;
  const CheckedCom = checkComponent || Checked;
  return (
    <TouchableOpacity
      testID={`radio-button-${name}-${index}`}
      disabled={disabled}
      onPress={() => {
        onPress && onPress(value);
      }}
    >
      <Box flexDirection="row" alignItems="center">
        <RadioCom
          touched={touched}
          checked={checked}
          error={error}
          alignItems="center"
          justifyContent="center"
        >
          {checked && <CheckedCom />}
        </RadioCom>

        <Text fontSize={18}>
          {intl.formatMessage({
            id: option.i18nId,
            defaultMessage: option.defaultLabel,
          })}
        </Text>
      </Box>
    </TouchableOpacity>
  );
};

const RadioButtonField = props => {
  const { validate, name, onSelect, radioComponent } = props;
  const validates = [validate].reduce((acc, val) => acc.concat(val), []);

  return (
    <Field {...props} type="radio" validate={runValidations(validates)}>
      {fieldProps => {
        const {
          input: { onChange, onBlur },
        } = fieldProps;
        return (
          <RadioButton
            name={name}
            onPress={value => {
              onBlur();
              onSelect && onSelect();
              onChange(value);
            }}
            radioComponent={radioComponent}
            {...fieldProps}
          />
        );
      }}
    </Field>
  );
};

export default RadioButtonField;
