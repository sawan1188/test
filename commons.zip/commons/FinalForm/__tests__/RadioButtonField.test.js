import { renderForTest } from '@testUtils';
import RadioButtonField from '../RadioButtonField';
import React from 'react';
import { fireEvent } from 'react-native-testing-library';
import { Form } from 'react-final-form';
import { createForm } from 'final-form';
import { TouchableOpacity } from 'react-native';

const changeValue = ([name, value], state, { changeValue }) => {
  changeValue(state, name, () => value);
};

const props = {
  input: {
    value: 'foo',
    onChange: jest.fn(),
    onBlur: jest.fn(),
  },
  selected: true,
  onSelect: jest.fn(),
  onError: jest.fn(),
  onTouch: jest.fn(),
  validate: jest.fn(),
  name: 'radio',
  option: { defaultLabel: 'Male', i18nId: 'picker.male' },
  meta: { error: false, touched: false },
};

const withForm = MyRadioButton => {
  const myForm = createForm({ onSubmit: jest.fn(), mutators: { changeValue } });
  return <Form form={myForm} render={() => <MyRadioButton {...props} />} />;
};

describe('RadioButton', () => {
  it('should call onBlur on press', () => {
    const component = renderForTest(withForm(RadioButtonField));
    const touchableOpacity = component.getByType(TouchableOpacity);
    fireEvent(touchableOpacity, 'onPress');
    expect(props.input.onBlur).toHaveBeenCalled();
  });
});
