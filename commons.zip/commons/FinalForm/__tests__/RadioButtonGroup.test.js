import { renderForTest } from '@testUtils';
import RadioButtonGroup from '../RadioButtonGroup';
import React from 'react';
import { Form } from 'react-final-form';
import { createForm } from 'final-form';
import { Icon } from 'react-native-elements';
import theme from '@theme';

const changeValue = ([name, value], state, { changeValue }) => {
  changeValue(state, name, () => value);
};

const props = {
  input: {
    value: 'foo',
  },
  name: 'radio',
  hint: 'hint',
  options: [
    { defaultLabel: 'Male', i18nId: 'picker.male' },
    { defaultLabel: 'Female', i18nId: 'picker.female' },
  ],
  onRight: ({ color }) => <Icon name="event" color={color} />,
  theme,
  meta: {
    error: '',
    touched: false,
  },
  intl: {
    formatMessage: jest.fn(() => 'foo'),
  },
  validate: jest.fn(),
};

const withForm = MyRadioButtonGroup => {
  const myForm = createForm({ onSubmit: jest.fn(), mutators: { changeValue } });
  return (
    <Form
      form={myForm}
      render={({ form, handleSubmit, submitting }) => (
        <MyRadioButtonGroup {...props} />
      )}
    />
  );
};

describe('RadioButtonGroup', () => {
  it('renders correctly', () => {
    const component = renderForTest(withForm(RadioButtonGroup));
    // expect(component.toJSON()).toMatchSnapshot();
  });
});
