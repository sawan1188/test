import { renderForTest } from '@testUtils';
import DatePicker from '../DatePicker';
import React from 'react';
import { Form } from 'react-final-form';
import { createForm } from 'final-form';
import { SelectField } from '../index';
import { fireEvent } from 'react-native-testing-library';
jest.mock(
  '@components/commons/Datepicker',
  () => require('@testUtils/__mocks__/MockDatePicker').DatePicker,
);
const changeValue = ([name, value], state, { changeValue }) => {
  changeValue(state, name, () => value);
};
const props = {
  field: {
    id: 'dateOfBirth',
    defaultLabel: 'Date of birth',
    type: 'Date',
    i18nId: 'signUp.signUpForm.dateOfBirth',
    required: true,
    visible: true,
    error: { id: 'signUp.signUpForm.dateOfBirthError' },
  },
  space: 1,
};

const withForm = MyDatePicker => {
  const myForm = createForm({ onSubmit: jest.fn(), mutators: { changeValue } });
  return (
    <Form
      form={myForm}
      render={({ form, handleSubmit, submitting }) => (
        <MyDatePicker field={props.field} mutators={form.mutators} />
      )}
    />
  );
};

describe('Date Picker', () => {
  test('renders correctly', () => {
    const component = renderForTest(withForm(DatePicker));

    const selectField = component.queryAllByType(SelectField);
    expect(selectField).toHaveLength(1);
  });

  test('should changeValue correctly', () => {
    const component = renderForTest(withForm(DatePicker));
    const datePickerComponent = component.queryByType(SelectField);

    fireEvent(datePickerComponent, 'confirm', new Date(0));
    const formComponent = component.queryByType(Form);
    expect(formComponent.props.form.getState().values.dateOfBirth).toEqual(
      '1970-01-01T00:00:00.000Z',
    );
    expect(
      formComponent.props.form.getState().values.dateOfBirthForView,
    ).toEqual('01 Jan 1970');
  });
});
