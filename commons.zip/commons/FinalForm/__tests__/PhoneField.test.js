import { renderForTest } from '@testUtils';
import PhoneField from '../PhoneField';
import React from 'react';
import { Form } from 'react-final-form';
import { createForm } from 'final-form';
import { fireEvent } from 'react-native-testing-library';
import ModalPicker from '@components/commons/ModalPicker';
import { SelectField } from '@components/commons/FinalForm';

const changeValue = ([name, value], state, { changeValue }) => {
  changeValue(state, name, () => value);
};

const props = {
  field: {
    id: 'gender',
    i18nId: 'picker.male',
    defaultLabel: 'Male',
    type: 'type',
    required: true,
    visible: true,
    defaultValue: 'male',
  },
  mutators: {
    changeValue: jest.fn(),
  },
  space: 123,
  onNext: jest.fn(),
  keyboardType: 'next',
  returnKeyType: 'phone-pad',
};

const withForm = MyPhoneField => {
  const myForm = createForm({ onSubmit: jest.fn(), mutators: { changeValue } });
  return <Form form={myForm} render={() => <MyPhoneField {...props} />} />;
};

describe('PhoneField', () => {
  it('should call mutators.changeValue when confirm selecting', () => {
    const component = renderForTest(withForm(PhoneField));
    const phoneField = component.getByType(ModalPicker);
    fireEvent(phoneField, 'onConfirm');
    expect(props.mutators.changeValue).toHaveBeenCalled();
  });

  it('should create SelectField', () => {
    const component = renderForTest(withForm(PhoneField));
    const selectField = component.getByType(SelectField);
    expect(selectField).toBeDefined();
  });

  it('call onPress on SelectField', () => {
    const component = renderForTest(withForm(PhoneField));
    const selectField = component.getByType(SelectField);
    fireEvent(selectField, 'onPress');
    expect(selectField).toBeDefined();
  });
});
