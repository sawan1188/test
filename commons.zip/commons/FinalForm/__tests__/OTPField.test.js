import { renderForTest } from '@testUtils';
import { Keyboard } from 'react-native';
import { InputField } from '@components/commons/FinalForm';
import { fireEvent } from 'react-native-testing-library';
import OTPField from '../OTPField';
import React from 'react';
import { Form } from 'react-final-form';
import { createForm } from 'final-form';

const changeValue = ([name, value], state, { changeValue }) => {
  changeValue(state, name, () => value);
};

const props = {
  field: {
    id: 'otp',
    i18nId: 'picker.male',
    defaultLabel: 'Male',
    type: 'OTP',
    required: true,
    visible: true,
    defaultValue: 'male',
  },
  mutators: {
    changeValue: jest.fn(),
  },
  onSubmitEditing: jest.fn(),
  space: 123,
  theme: {
    colors: {
      errors: ['#FF0000'],
    },
  },
};

Keyboard.dismiss = jest.fn();

const withForm = (MyOTPField, fieldProps) => {
  const myForm = createForm({ onSubmit: jest.fn(), mutators: { changeValue } });
  return (
    <Form
      form={myForm}
      render={({ form, handleSubmit, submitting }) => (
        <MyOTPField {...fieldProps} />
      )}
    />
  );
};

describe('OTPField', () => {
  it('should render correctly', () => {
    const component = renderForTest(withForm(OTPField, props));
    // expect(component.toJSON()).toMatchSnapshot();
  });

  it('should render 4 input field by default', () => {
    const component = renderForTest(withForm(OTPField, props));

    const inputField = component.queryAllByType(InputField);
    expect(inputField).toHaveLength(4);
  });

  it('should render 8 input fields when set numberOfInputs in the fields param as 8', () => {
    const newProps = { ...props };
    newProps.field.numberOfInputs = 8;
    const component = renderForTest(withForm(OTPField, newProps));

    const inputField = component.queryAllByType(InputField);
    expect(inputField).toHaveLength(8);
  });

  it('should call changeValue mutators on Focus of the fields', () => {
    const component = renderForTest(withForm(OTPField, props));

    const inputField = component.queryAllByType(InputField);

    fireEvent(inputField[0], 'onFocus');
    expect(props.mutators.changeValue).toHaveBeenCalled();
  });

  it('should call changeValue mutators on Change Text of the fields', () => {
    const component = renderForTest(withForm(OTPField, props));

    const inputField = component.queryAllByType(InputField);

    fireEvent(inputField[0], 'onChangeText', '1');
    expect(props.mutators.changeValue).toHaveBeenCalled();
  });

  it('should call onSubmitEdting mutators on Change Text of the fields', () => {
    const component = renderForTest(withForm(OTPField, props));

    const inputField = component.queryAllByType(InputField);

    fireEvent(inputField[inputField.length - 1], 'onChangeText', '1');
    expect(Keyboard.dismiss).toHaveBeenCalled();
  });

  it('should call changeValue mutators on Key Press of the fields other than the first field', () => {
    const component = renderForTest(withForm(OTPField, props));

    const inputField = component.queryAllByType(InputField);

    fireEvent(inputField[1], 'onKeyPress', {
      nativeEvent: { key: 'Backspace' },
    });
    expect(props.mutators.changeValue).toHaveBeenCalled();
  });

  it('should call Keyboard dismiss on Key Press of the first field', () => {
    const component = renderForTest(withForm(OTPField, props));

    const inputField = component.queryAllByType(InputField);

    fireEvent(inputField[0], 'onKeyPress', {
      nativeEvent: { key: 'Backspace' },
    });
    expect(Keyboard.dismiss).toHaveBeenCalled();
  });
});
