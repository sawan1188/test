import { renderForTest } from '@testUtils';
import GenderRadio from '../GenderRadio';
import React from 'react';
import { Form } from 'react-final-form';
import { createForm } from 'final-form';

const changeValue = ([name, value], state, { changeValue }) => {
  changeValue(state, name, () => value);
};

const props = {
  field: {
    id: 'gender',
    i18nId: 'picker.male',
    defaultLabel: 'Male',
    type: 'type',
    required: true,
    visible: true,
    defaultValue: 'male',
  },
  mutators: {
    changeValue: jest.fn(),
  },
  space: 123,
};

const withForm = MyGenderRadio => {
  const myForm = createForm({ onSubmit: jest.fn(), mutators: { changeValue } });
  return (
    <Form
      form={myForm}
      render={({ form, handleSubmit, submitting }) => (
        <MyGenderRadio {...props} />
      )}
    />
  );
};

describe('GenderRadio', () => {
  it('renders correctly', () => {
    const component = renderForTest(withForm(GenderRadio));
    // expect(component.toJSON()).toMatchSnapshot();
  });
});
