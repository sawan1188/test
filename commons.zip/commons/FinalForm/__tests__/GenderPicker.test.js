import React from 'react';
import { Form } from 'react-final-form';
import { fireEvent } from 'react-native-testing-library';
import { renderForTest } from '@testUtils';
import GenderPicker from '../GenderPicker';
import ModalPicker from '@components/commons/ModalPicker';
import { SelectField } from '@components/commons/FinalForm';

const props = {
  field: {
    id: 'gender',
    i18nId: 'picker.male',
    defaultLabel: 'Male',
    type: 'type',
    required: true,
    visible: true,
    defaultValue: 'male',
  },
  mutators: {
    changeValue: jest.fn(),
  },
  space: 123,
};

const formProps = {
  initialValues: {},
  onSubmit: jest.fn(),
  render: jest.fn().mockReturnValue(<GenderPicker {...props} />),
};

describe('GenderPicker', () => {
  it('should render correctly', () => {
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const genderPicker = formWithGenderPicker.getByType(GenderPicker);
    expect(genderPicker.props.space).toEqual(props.space);
    expect(genderPicker.props.field.i18nId).toEqual(props.field.i18nId);
  });

  it('should call mutators.changeValue when confirm selecting', () => {
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const modalPicker = formWithGenderPicker.getByType(ModalPicker);
    fireEvent(modalPicker, 'onConfirm');
    expect(props.mutators.changeValue).toHaveBeenCalled();
  });

  it('should call mutators.changeValue when confirm selecting with params', () => {
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const modalPicker = formWithGenderPicker.getByType(ModalPicker);
    fireEvent(modalPicker, 'onConfirm', { i18nId: 'picker.female' });
    expect(props.mutators.changeValue).toHaveBeenCalled();
  });

  it('should create SelectField', () => {
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const selectField = formWithGenderPicker.getByType(SelectField);
    expect(selectField).toBeDefined();
  });

  it('call onPress on SelectField', () => {
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const selectField = formWithGenderPicker.getByType(SelectField);
    fireEvent(selectField, 'onPress');
    expect(selectField).toBeDefined();
  });

  it('should validate with specified messageId', () => {
    const props = {
      field: {
        id: 'gender',
        i18nId: 'picker.male',
        defaultLabel: 'Male',
        type: 'type',
        required: true,
        visible: true,
        defaultValue: 'male',
        error: {
          id: 'isRequired',
        },
      },
      mutators: {
        changeValue: jest.fn(),
      },
      space: 123,
    };

    const formProps = {
      initialValues: {},
      onSubmit: jest.fn(),
      render: jest.fn().mockReturnValue(<GenderPicker {...props} />),
    };
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const selectField = formWithGenderPicker.getByType(SelectField);
    expect(selectField).toBeDefined();
  });

  it('should not call getValidation when field is not required', () => {
    const props = {
      field: {
        id: 'gender',
        i18nId: 'picker.male',
        defaultLabel: 'Male',
        type: 'type',
        required: false,
        visible: true,
        defaultValue: 'male',
        error: {
          id: 'isRequired',
        },
      },
      mutators: {
        changeValue: jest.fn(),
      },
      space: 123,
    };

    const formProps = {
      initialValues: {},
      onSubmit: jest.fn(),
      render: jest.fn().mockReturnValue(<GenderPicker {...props} />),
    };
    const formWithGenderPicker = renderForTest(<Form {...formProps} />);
    const selectField = formWithGenderPicker.getByType(SelectField);
    fireEvent(selectField, 'validate');
    expect(selectField).toBeDefined();
  });
});
