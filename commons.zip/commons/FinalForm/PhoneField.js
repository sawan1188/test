import { Box, InputLabel } from '@components/commons';
import PropTypes from 'prop-types';
import React, { useImperativeHandle, useState } from 'react';
import { useIntl } from '../hooks';
import { InputField, SelectField } from '@components/commons/FinalForm';
import ModalPicker from '@components/commons/ModalPicker';
import { validateRequiredWithMessageId } from '@components/commons/validations';
import { Icon } from 'react-native-elements';
import { View } from 'react-native';

const PhoneField = React.forwardRef(
  (
    {
      field,
      mutators,
      onNext,
      keyboardType,
      returnKeyType,
      inputFieldComponent,
      selectFieldComponent,
      customStylesInput,
    },
    ref,
  ) => {
    const intl = useIntl();
    const [countryCode, setCountryCode] = useState('+65');
    const [phone, setPhone] = useState('+65');
    const countryCodeOption = [
      {
        displayText: '+65',
        defaultLabel: '+65 Singapore',
        i18nId: 'countryCode.singapore',
        value: '+65',
      },
    ];

    const phoneRef = React.useRef({ setIsVisible: null });
    const inputRef = React.useRef();
    const getValidation = field => {
      const messageId = field.error?.i18nId || null;
      return value => validateRequiredWithMessageId({ value, messageId });
    };

    useImperativeHandle(ref, () => ({
      focus: () => {
        phoneRef.current.setIsVisible && phoneRef.current.setIsVisible(true);
      },
    }));

    const InputCom = inputFieldComponent || InputField;
    const SelectCom = selectFieldComponent || SelectField;

    return (
      <Box height={110} pt={10}>
        <InputLabel required={field.required}>
          {intl.formatMessage({
            id: field.i18nId,
            defaultMessage: field.defaultLabel,
          })}
        </InputLabel>
        <Box flexDirection="row">
          <Box width={100} mr={10}>
            <ModalPicker
              options={countryCodeOption}
              title={intl.formatMessage({
                id: 'signUp.signUpForm.countryCodeTitle',
              })}
              onConfirm={item => {
                mutators.changeValue(
                  `${field.id}-countryCodeForView`,
                  item ? item.value : '',
                );
                setCountryCode(item ? item.value : '+65');
                item &&
                  item.value &&
                  mutators.changeValue(`${field.id}`, `${item.value}${phone}`);

                setTimeout(() => {
                  inputRef.current && inputRef.current.focus();
                }, 400);
              }}
              field={({ setIsVisible }) => {
                if (!phoneRef?.current?.setIsVisible)
                  phoneRef.current.setIsVisible = setIsVisible;
                return (
                  <SelectCom
                    initialValue={'+65'}
                    type={field.type}
                    name={`${field.id}-countryCodeForView`}
                    validate={field.required ? getValidation(field) : () => {}}
                    onPress={() => {
                      setIsVisible && setIsVisible(true);
                    }}
                    onRight={() => <Icon name="expand-more" />}
                    disabled={true}
                  />
                );
              }}
            />
          </Box>
          <Box flex={1}>
            <InputCom
              field={field}
              ref={inputRef}
              validate={field.required ? getValidation(field) : () => {}}
              name={`${field.id}ForView`}
              type={field.type}
              labelComponent={<View />}
              keyboardType={keyboardType}
              returnKeyType={returnKeyType}
              testID={field.id}
              onSubmitEditing={onNext}
              onChangeText={value => {
                setPhone(value);
                mutators.changeValue(`${field.id}`, `${countryCode}${value}`);
              }}
              customStyles={customStylesInput}
            />
          </Box>
        </Box>
      </Box>
    );
  },
);

PhoneField.propTypes = {
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  secureTextEntry: PropTypes.bool,
  hint: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  keyboardType: PropTypes.string,
  autoCapitalize: PropTypes.string,
  returnKeyType: PropTypes.string,
  rightIcon: PropTypes.node,
  leftIcon: PropTypes.node,
  onSubmitEditing: PropTypes.func,
  onTouchStart: PropTypes.func,
  editable: PropTypes.bool,
  onPress: PropTypes.func,
  accessibilityLabel: PropTypes.string,
  validationErrorsLocalized: PropTypes.bool,
};

export default PhoneField;
