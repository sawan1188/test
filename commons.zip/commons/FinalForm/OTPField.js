import React, { useRef } from 'react';
import { Dimensions, Keyboard, StyleSheet } from 'react-native';
import { InputLabel, Box } from '@components/commons';
import { InputField } from '@components/commons/FinalForm';
import PropTypes from 'prop-types';
import { useIntl } from '../hooks';
import styled, { withTheme } from 'styled-components/native';
import { Field, useForm } from 'react-final-form';
import theme from '@theme';

const { width: W_WIDTH } = Dimensions.get('window');
const inputWidth = (W_WIDTH - 32 * 2) / 4;

const customStylesInput = StyleSheet.create({
  inputContainerStyle: {
    borderBottomWidth: 1,
    borderWidth: 0,
    paddingLeft: 0,
    paddingRight: 0,
    paddingBottom: 5,
    borderRadius: 0,
    marginLeft: 2.5,
    marginRight: 2.5,
    borderColor: theme.colors.gray[8],
    position: 'relative',
  },
  inputStyle: {
    height: 100,
    textAlign: 'center',
    fontSize: 40,
    marginBottom: -10,
  },
  errorMessage: {
    top: 110,
    left: -3,
  },
});

const OTPField = ({
  field,
  mutators,
  numberOfInputs,
  customStyles = {},
  inputFieldComponent,
}) => {
  const intl = useIntl();
  const { resetFieldState } = useForm();

  const iterationArray = Array(
    (field && field.numberOfInputs) || numberOfInputs || 4,
  ).fill('');

  const arrayRef = [];
  for (let i of iterationArray) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    arrayRef.push(useRef(null));
  }
  const otpRef = useRef(arrayRef);

  const handleOnNextItem = index => text => {
    if (otpRef.current.length - 1 === index && text) {
      Keyboard.dismiss();
      return;
    }

    if (text) {
      otpRef.current[index + 1]?.current?.focus();
    }
  };

  const focusPrevious = index => ({ nativeEvent: { key } }) => {
    if (key === 'Backspace') {
      if (index > 0) {
        otpRef.current[index - 1]?.current?.focus();
      } else {
        Keyboard.dismiss();
      }
    }
  };

  const ErrorText = styled.Text`
    position: absolute;
    top: 110;
    left: 0;
    font-size: 12px;
    ${({ theme }) => `
  color: ${theme.colors.error[0]}
`};
  `;

  const InputCom = inputFieldComponent || InputField;

  return (
    <Box mb={50}>
      <InputLabel
        required={field.required}
        labelStyle={{
          ...customStyles.labelStyle,
        }}
      >
        {intl.formatMessage({
          id: field.i18nId,
          defaultMessage: field.defaultLabel,
        })}
      </InputLabel>

      <Box flexDirection="row">
        {iterationArray.map((_, index) => (
          <Box width={inputWidth} key={index}>
            <InputCom
              ref={otpRef.current[index]}
              returnKeyType={
                index === iterationArray.length - 1 ? 'send' : 'next'
              }
              onKeyPress={focusPrevious(index)}
              onChangeText={handleOnNextItem(index)}
              onSubmitEditing={handleOnNextItem(index)}
              onFocus={e => {
                mutators.changeValue(`${field.id}s[${index}]`, '');
              }}
              name={`${field.id}s[${index}]`}
              type={field.type}
              keyboardType="numeric"
              testID={field.id}
              maxLength={1}
              customStyles={{ ...customStylesInput, ...customStyles }}
            />
          </Box>
        ))}
      </Box>
      <Field name={`${field.id}`} validate={() => {}}>
        {({ meta }) => {
          return meta.submitError ? (
            <ErrorText>{meta.submitError}</ErrorText>
          ) : null;
        }}
      </Field>
    </Box>
  );
};

OTPField.propTypes = {
  numberOfInputs: PropTypes.number,
  onSubmitEditing: PropTypes.func,
};

export default withTheme(OTPField);
