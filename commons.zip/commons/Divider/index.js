import React from 'react';
import { Box } from '@components/commons';

const Divider = ({ full, ...props }) => {
  const divider = (
    <Box width="100%" height={1} backgroundColor="gray.5" {...props} />
  );
  return !full ? (
    <Box pl={4} pr={4}>
      {divider}
    </Box>
  ) : (
    divider
  );
};

export default Divider;
