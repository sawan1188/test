import React, { useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import { StyleSheet } from 'react-native';
import { Button as NativeButton } from 'react-native-elements';
import { useTheme } from '@components/commons/hooks';
import LinearGradient from 'react-native-linear-gradient';
import withTracking from '../Tracking';

const Button = ({
  primary,
  secondary,
  outline,
  transparent,
  buttonStyle,
  titleStyle,
  onPress,
  ...props
}) => {
  const theme = useTheme();
  const [isDisabled, setIsDisabled] = useState(false);
  const overridedOnPress = () => {
    if (!isDisabled) {
      setIsDisabled(true);
      onPress();
    }

    setTimeout(() => {
      setIsDisabled(false);
    }, 1000);
  };

  const styles = useMemo(
    () =>
      StyleSheet.create({
        base: {
          height: 48,
        },
        primary: {
          backgroundColor: theme.colors.primary[0],
        },
        secondary: {
          backgroundColor: theme.colors.gray[7],
          borderColor: theme.colors.gray[1],
          borderWidth: 1,
        },
        outline: {
          backgroundColor: theme.colors.gray[7],
          borderColor: theme.colors.gray[0],
          borderWidth: 1,
        },
        transparent: {
          backgroundColor: 'transparent',
          borderWidth: 0,
        },
        primaryTitle: {
          color: 'white',
          fontFamily: theme.fonts.default,
          fontSize: 16,
          lineHeight: 20,
        },
        secondaryTitle: {
          color: theme.colors.gray[0],
          fontFamily: theme.fonts.default,
          fontSize: 16,
          lineHeight: 20,
        },
        outlineTitle: {
          color: theme.colors.gray[0],
          fontFamily: theme.fonts.default,
          fontSize: 16,
          lineHeight: 20,
        },
      }),
    [theme],
  );

  return (
    <NativeButton
      onPress={overridedOnPress}
      disabled={isDisabled || props.disabled}
      accessibilityLabel={props.title}
      buttonStyle={{
        ...styles.base,
        ...(primary ? styles.primary : {}),
        ...(secondary ? styles.secondary : {}),
        ...(outline ? styles.outline : {}),
        ...(transparent ? styles.transparent : {}),
        ...(buttonStyle || {}),
      }}
      titleStyle={{
        ...(primary ? styles.primaryTitle : {}),
        ...(secondary ? styles.secondaryTitle : {}),
        ...(outline ? styles.outlineTitle : {}),
        ...(titleStyle || {}),
      }}
      {...props}
    />
  );
};

Button.propTypes = {
  color: PropTypes.string,
  primary: PropTypes.bool,
  secondary: PropTypes.bool,
  outline: PropTypes.bool,
  buttonStyle: PropTypes.shape({}),
  titleStyle: PropTypes.shape({}),
};

export const GradientButton = props => {
  const { horizontal, colors, buttonStyle, ...restProps } = props;
  return (
    <LinearGradient
      {...(horizontal ? { start: { x: 0, y: 0 }, end: { x: 1, y: 0 } } : {})}
      colors={colors ? colors : []}
      style={{ ...(buttonStyle || {}) }}
    >
      <Button transparent={true} {...restProps} />
    </LinearGradient>
  );
};

export const TrackedButton = withTracking(Button);

export default Button;
