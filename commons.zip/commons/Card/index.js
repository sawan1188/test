import { Box } from '@components/commons';
import styled from 'styled-components/native';

const Card = styled(Box)`
  border-radius: 4px;
  shadow-offset: 0px 2px;
  shadow-opacity: 0.05px;
  shadow-radius: 3;
  shadow-color: #000;
`;

export default Card;
