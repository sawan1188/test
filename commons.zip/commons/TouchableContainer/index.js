/* istanbul ignore file */
import React from 'react';
import {
  space,
  alignItems,
  justifyContent,
  display,
  flex,
  flexDirection,
} from 'styled-system';
import styled from 'styled-components/native';
import { useTheme } from '@components/commons/hooks';

const TouchableHighlight = styled.TouchableHighlight`
  ${space}
  ${flex}
  ${flexDirection}
  ${display}
  ${alignItems}
  ${justifyContent}
`;

const TouchableContainer = ({ children, onPress, ...otherProps }) => {
  const theme = useTheme();
  const pressHandler = onPress || (() => {});

  return (
    <TouchableHighlight
      {...otherProps}
      onPress={pressHandler}
      underlayColor={theme.colors.touchableOverlayColor}
    >
      {children}
    </TouchableHighlight>
  );
};

export default TouchableContainer;
