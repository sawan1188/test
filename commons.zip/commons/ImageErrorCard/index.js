import React from 'react';
import { Box, SecondaryText } from '@components/commons';
import { FormattedMessage } from 'react-intl';

const ImageErrorCard = props => (
  <Box
    px={3}
    borderRadius={2}
    backgroundColor="gray.6"
    justifyContent="center"
    alignItems="center"
    {...props}
  >
    <SecondaryText textAlign="center">
      <FormattedMessage id="image.error.unableToLoad" />
    </SecondaryText>
  </Box>
);

export default ImageErrorCard;
