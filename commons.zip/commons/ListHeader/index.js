import React from 'react';
import { Box, SectionHeadingText } from '@components/commons';

const ListHeader = ({ text, ...props }) => {
  return (
    <Box px={32} py={8} {...props}>
      <SectionHeadingText>{text}</SectionHeadingText>
    </Box>
  );
};

export default ListHeader;
