import React from 'react';
import { FormattedNumber } from 'react-intl';

const FormattedMoney = props => (
  <FormattedNumber
    format="money"
    minimumFractionDigits={2}
    maximumFractionDigits={2}
    {...props}
  />
);

export default FormattedMoney;
