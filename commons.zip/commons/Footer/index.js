/* istanbul ignore file */
import { isIphoneX, IPHONEX_BOTTOM_PADDING } from '@utils';
import styled from 'styled-components/native';
import { Box } from '@components/commons';

const Footer = styled(Box)`
  ${({ theme }) => `
   border-top-color: ${theme.colors.gray[5]}
   border-top-width: 1px
  `}
  padding-left: 32px;
  padding-right: 32px;
  padding-top: 16px;
  padding-bottom: ${isIphoneX() ? `${IPHONEX_BOTTOM_PADDING + 16}px` : '16px'};
  ${({ flexDirection }) => `flex-direction: ${flexDirection}`}
`;

export default Footer;
