const MAX_AMOUNT_FIELD_LENGTH = 20;
const MAX_CONTACT_NUMBER_LENGTH = 16;
const amountRegex = /\d*(\.\d{0,2})?/;

export const normalizeAmount = (value, previousValue) => {
  if (!value) return value;
  const trimmedAmount = value.substring(0, MAX_AMOUNT_FIELD_LENGTH);
  const match = trimmedAmount.match(amountRegex);
  return match && match[0] ? match[0] : previousValue;
};

export const normalizeContactNumber = value => {
  if (!value) return value;
  const numbersOnly = value.replace(/[^0-9\+]/g, '');
  return numbersOnly.substring(0, MAX_CONTACT_NUMBER_LENGTH);
};
