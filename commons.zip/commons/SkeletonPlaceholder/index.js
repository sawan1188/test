/* istanbul ignore file */
import React from 'react';
import { Dimensions } from 'react-native';
import ShimmerPlaceholder from 'react-native-shimmer-placeholder';
import styled from 'styled-components/native';
import { size, space, borderRadius } from 'styled-system';
import { useTheme } from '@components/commons/hooks';
import { Box, ListItem } from '@components/commons';
import SvgAnimatedLinearGradient from 'react-native-svg-animated-linear-gradient';

const StyledShimmerPlaceholder = styled(ShimmerPlaceholder)`
  ${space}
  ${size}
  ${borderRadius}
`;

StyledShimmerPlaceholder.defaultProps = {
  borderRadius: 4,
};

const SkeletonPlaceholder = props => {
  const theme = useTheme();
  const gradientStartStop = theme.colors.gray[6];
  const gradientMiddle = theme.colors.gray[5];

  const viewportWidth = Dimensions.get('window').width;
  const viewportPadding = theme.space[4];
  const width = viewportWidth - viewportPadding * 2;

  const colorShimmer = [gradientStartStop, gradientMiddle, gradientStartStop];
  return (
    <StyledShimmerPlaceholder
      autoRun
      colorShimmer={colorShimmer}
      width={width}
      {...props}
    />
  );
};

const SectionLabelValueListSkeletonPlaceholder = ({ count }) => (
  <>
    <Box pt={4} pl={4} pr={4} pb={2}>
      <TextSkeletonPlaceholder width={164} />
    </Box>
    <ListSkeletonPlaceholder count={count}>
      <TextSkeletonPlaceholder width={124} />
      <Box mt={1}>
        <TextSkeletonPlaceholder width={244} />
      </Box>
    </ListSkeletonPlaceholder>
  </>
);

const SectionListSkeletonPlaceholder = ({ count, ...props }) => (
  <>
    <Box pt={4} pl={4} pr={4} pb={2}>
      <TextSkeletonPlaceholder width={220} />
    </Box>
    <ListSkeletonPlaceholder count={count} {...props} />
  </>
);

const ListSkeletonPlaceholder = ({
  count = 3,
  leftIcon,
  rightIcon,
  children,
  ...props
}) => {
  return Array.from({ length: count }).map((_, index) => (
    <ListItem key={index} leftIcon={leftIcon} rightIcon={rightIcon}>
      {children ? children : <TextSkeletonPlaceholder {...props} />}
    </ListItem>
  ));
};

const ParagraphSkeletonPlaceholder = ({ count = 3, ...props }) => {
  return (
    <>
      {Array.from({ length: count - 1 }).map((_, index) => (
        <Box key={index} mb={2}>
          <TextSkeletonPlaceholder {...props} />
        </Box>
      ))}
      <TextSkeletonPlaceholder width={164} />
    </>
  );
};

const TextSkeletonPlaceholder = ({
  fontSize = 22,
  lineHeight = 22,
  ...props
}) => (
  <Box height={lineHeight} justifyContent="center">
    <SkeletonPlaceholder height={fontSize} {...props} />
  </Box>
);

const IconSkeletonPlaceholder = ({ height = 24, width = 24, ...props }) => (
  <SkeletonPlaceholder height={height} width={width} {...props} />
);

const ImageSkeletonPlaceholder = ({ height = 176, width = 128, ...props }) => (
  <SkeletonPlaceholder height={height} width={width} {...props} />
);

const FieldSkeletonPlaceholder = ({ height = 56, ...props }) => (
  <SkeletonPlaceholder height={height} {...props} />
);

const ButtonSkeletonPlaceholder = ({ height = 48, ...props }) => (
  <SkeletonPlaceholder height={height} {...props} />
);

const SvgSkeletonPlaceholder = props => {
  const theme = useTheme();
  const gradientStartStop = theme.colors.gray[6];
  const gradientMiddle = theme.colors.gray[5];

  return (
    <SvgAnimatedLinearGradient
      primaryColor={gradientStartStop}
      secondaryColor={gradientMiddle}
      {...props}
    />
  );
};

export {
  FieldSkeletonPlaceholder,
  ButtonSkeletonPlaceholder,
  IconSkeletonPlaceholder,
  TextSkeletonPlaceholder,
  ImageSkeletonPlaceholder,
  ListSkeletonPlaceholder,
  ParagraphSkeletonPlaceholder,
  SectionListSkeletonPlaceholder,
  SectionLabelValueListSkeletonPlaceholder,
  SvgSkeletonPlaceholder,
};
export default SkeletonPlaceholder;
