/* istanbul ignore file */
import React, { useRef, useState } from 'react';
import Carousel from 'react-native-snap-carousel';
import { useDebouncedCallback } from 'use-debounce';
import { logAction } from '@store/analytics/trackingActions';
import { Animated, Dimensions, View } from 'react-native';

export const TrackedCarousel = props => {
  const { actionParams, onSnapToItem, data } = props;
  const [maxReachedIndex, setMaxReachedIndex] = useState(0);

  const [debounceLogAction] = useDebouncedCallback(percent => {
    logAction({
      ...actionParams,
      percent,
    });
  }, 1000 * 30);

  return (
    <Carousel
      {...props}
      onSnapToItem={snapIndex => {
        if (onSnapToItem) {
          onSnapToItem(snapIndex);
        }

        if (actionParams && snapIndex > maxReachedIndex) {
          setMaxReachedIndex(snapIndex);

          debounceLogAction((snapIndex + 1) / data.length);
        }
      }}
    />
  );
};

const www = Dimensions.get('window').width - 32 * 2;
export const withScrollBar = ScrollableComponent => props => {
  const scrollOffset = useRef(new Animated.Value(0));
  const [scrollContentWidth, setScrollContentWidth] = useState(0);
  const [scrollWidth, setScrollWidth] = useState(0);

  return (
    <>
      <ScrollableComponent
        {...props}
        onContentSizeChange={w => setScrollContentWidth(w)}
        onLayout={e => setScrollWidth(e.nativeEvent.layout.width)}
        onScroll={Animated.event(
          [
            {
              nativeEvent: {
                contentOffset: { x: scrollOffset.current },
              },
            },
          ],
          { useNativeDriver: true },
        )}
      />
      {scrollContentWidth > 0 && scrollWidth < scrollContentWidth && (
        <View style={{ alignItems: 'center' }}>
          <View
            style={{
              flex: 1,
              marginTop: 16,
              backgroundColor: '#D7D8D6',
              width: www,
              height: 5,
              borderRadius: 10,
            }}
          >
            <Animated.View
              style={{
                backgroundColor: 'black',
                borderRadius: 10,
                height: 5,
                width: (scrollWidth / scrollContentWidth) * www,
                transform: [
                  {
                    translateX: scrollOffset.current.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0, www / scrollContentWidth],
                    }),
                  },
                ],
              }}
            />
          </View>
        </View>
      )}
    </>
  );
};

export const TrackedCarouselWithScrollBar = withScrollBar(TrackedCarousel);

export default Carousel;
