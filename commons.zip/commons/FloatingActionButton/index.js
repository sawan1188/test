/* istanbul ignore file */
import React from 'react';
import PropTypes from 'prop-types';
import {
  Platform,
  TouchableHighlight,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import styled from 'styled-components/native';
import { Icon } from 'react-native-elements';
import { Box } from '@components/commons';
import withTracking from '../Tracking';
import { useTheme } from '@components/commons/hooks';

const ButtonContainer = styled(View)`
  border-color: white;
  border-radius: 28;
  shadow-offset: 0px 3px;
  shadow-opacity: 0.2;
  shadow-radius: 3;
  shadow-color: #000;
  elevation: 4;
  overflow: hidden;
`;

const ButtonWrapper = styled(View)`
  width: 56;
  height: 56;
  border-radius: 28;
  background-color: ${({ theme }) => theme.colors.buttonPrimary};
  align-items: center;
  justify-content: center;
`;

const AndroidFAB = ({ onPress, children, ...props }) => {
  const theme = useTheme();
  return (
    <TouchableNativeFeedback
      background={TouchableNativeFeedback.Ripple(
        theme.colors.buttonPrimaryPressed,
      )}
      onPress={onPress}
      {...props}
    >
      <ButtonWrapper>{children}</ButtonWrapper>
    </TouchableNativeFeedback>
  );
};

AndroidFAB.propTypes = {
  onPress: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
};

const GenericFAB = props => {
  const theme = useTheme();
  return (
    <ButtonWrapper
      as={TouchableHighlight}
      underlayColor={theme.colors.buttonPrimaryPressed}
      {...props}
    />
  );
};

const FloatingActionButton = props => {
  const FABComponent = Platform.OS === 'android' ? AndroidFAB : GenericFAB;
  return (
    <Box position="absolute" right={16} bottom={18} zIndex={1}>
      <ButtonContainer>
        <FABComponent {...props}>
          <Icon name="add" size={26} color="white" />
        </FABComponent>
      </ButtonContainer>
    </Box>
  );
};

FloatingActionButton.propTypes = {
  onPress: PropTypes.func.isRequired,
};

export const TrackedFloatingActionButton = withTracking(FloatingActionButton);

export default FloatingActionButton;
