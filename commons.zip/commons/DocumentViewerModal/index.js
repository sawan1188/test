import React, { useState, useEffect } from 'react';
import { StyleSheet } from 'react-native';
import ImageZoom from 'react-native-image-pan-zoom';
import { Box, Image, Pdf } from '@components/commons';
import { getImageSizeFromUri, getImageSizeRelativeToView } from '@utils';
import theme from '@theme';

const ImageViewer = ({ secure, uri }) => {
  const [viewSize, setViewSize] = useState(null);
  const [imageSize, setImageSize] = useState(null);

  useEffect(() => {
    async function executeGetImageSize() {
      const imageSize = await getImageSizeFromUri(uri, secure);
      setImageSize(imageSize);
    }
    executeGetImageSize();
  }, [uri, secure]);
  const shouldDisplayImage = viewSize && imageSize;

  const relativeImageSize =
    shouldDisplayImage && getImageSizeRelativeToView(imageSize, viewSize);

  return (
    <Box
      backgroundColor={theme.colors.black}
      onLayout={event => {
        const layoutViewSize = event.nativeEvent.layout;
        setViewSize(layoutViewSize);
      }}
      height="100%"
    >
      {shouldDisplayImage && (
        <ImageZoom
          cropWidth={viewSize.width}
          cropHeight={viewSize.height}
          imageWidth={relativeImageSize.width}
          imageHeight={relativeImageSize.height}
        >
          <Image secure={secure} source={{ uri }} width="100%" height="100%" />
        </ImageZoom>
      )}
    </Box>
  );
};

const PdfViewer = ({ uri, secure }) => (
  <Box flex={1} justifyContent="flex-start" alignItems="center">
    <Pdf
      secure={secure}
      source={{
        uri,
        cache: false,
      }}
      style={{
        backgroundColor: '#000',
        ...StyleSheet.absoluteFill,
      }}
      enableAnnotationRendering={false}
      onError={error => {
        console.log(error);
      }}
    />
  </Box>
);

const DocumentViewerModal = ({ route }) => {
  const { uri, contentType, secure } = route?.params || {};
  const PDF_CONTENT = 'application/pdf';
  const isPdf = contentType === PDF_CONTENT;

  return isPdf ? (
    <PdfViewer secure={secure} uri={uri} />
  ) : (
    <ImageViewer secure={secure} uri={uri} />
  );
};

export default DocumentViewerModal;
