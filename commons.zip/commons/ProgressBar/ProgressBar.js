import React from 'react';
import styled from 'styled-components/native';
import { Box } from '@components/commons';
import PropTypes from 'prop-types';

const ProgressBarContainer = styled(Box)`
  display: flex;
  flex-direction: row;
  height: 4;
`;

const ProgressBarItem = styled(Box)`
  ${({ active, progress, theme, activeColor }) => `
    border-top-right-radius: ${!active ? 2.5 : 0};
    border-bottom-right-radius: ${!active ? 2.5 : 0};
    border-top-left-radius: ${active ? 2.5 : 0};
    border-bottom-left-radius: ${active ? 2.5 : 0};
    background: ${
      active
        ? activeColor
          ? activeColor
          : theme.colors.blue[0]
        : theme.colors.gray[5]
    };
    width: ${progress * 100}%;
  `}
`;

const ProgressBar = ({ progress, activeColor, ...props }) => {
  return (
    <ProgressBarContainer {...props}>
      <ProgressBarItem progress={progress} active activeColor={activeColor} />
      <ProgressBarItem progress={1 - progress} />
    </ProgressBarContainer>
  );
};

ProgressBar.propTypes = {
  progress: PropTypes.number,
  activeColor: PropTypes.string,
};

export default ProgressBar;
