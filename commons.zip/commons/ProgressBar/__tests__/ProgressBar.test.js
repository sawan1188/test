import React from 'react';
import { ProgressBar } from '@components/commons';
import { renderForTest } from '@testUtils';

describe('Progress Bar', () => {
  it('should render ProgressBar', () => {
    const { getByType, toJSON } = renderForTest(<ProgressBar progress={0.3} />);
    const progressBar = getByType(ProgressBar);
    expect(progressBar).toBeDefined();
    const progressBarCompleted =
      progressBar.children[0].props.children[0].props;
    expect(progressBarCompleted.progress).toBe(0.3);
    expect(progressBarCompleted.active).toBe(true);

    const progressBarPending = progressBar.children[0].props.children[1].props;
    expect(progressBarPending.progress).toBe(0.7);
    expect(progressBarPending.active).toBeFalsy();

    // expect(toJSON()).toMatchSnapshot();
  });

  it('should render ProgressBar with activeColor properly', () => {
    const { getByType, toJSON } = renderForTest(
      <ProgressBar progress={0.3} activeColor={'#00000030'} />,
    );
    const progressBar = getByType(ProgressBar);
    const progressBarCompleted =
      progressBar.children[0].props.children[0].props;
    expect(progressBarCompleted.activeColor).toBe('#00000030');
  });
});
