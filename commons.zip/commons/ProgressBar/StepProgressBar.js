/* istanbul ignore file */
import React from 'react';
import PropTypes from 'prop-types';
import { Box } from '@components/commons';
import styled from 'styled-components/native';

const ProgressBarContainer = styled.View`
  display: flex;
  flex-direction: row;
  height: 3;
`;

const ProgressBarItem = styled(Box)`
  flex: 1;
  ${({ theme, active }) => `
    background: ${active ? theme.colors.gray[2] : theme.colors.gray[5]}
  `}
`;

const StepProgressBar = ({ currentStep, stepCount }) => (
  <ProgressBarContainer>
    {[...Array(stepCount).keys()].map(i => (
      <ProgressBarItem
        width={1 / stepCount}
        ml={i === 0 ? 0 : 1}
        active={i <= currentStep - 1}
        key={i}
      />
    ))}
  </ProgressBarContainer>
);

StepProgressBar.propTypes = {
  currentStep: PropTypes.number,
  stepCount: PropTypes.number,
};

export default StepProgressBar;
