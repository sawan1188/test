import React from 'react';
import PropTypes from 'prop-types';
import { Box, Divider } from '@components/commons';
import withTracking from '../Tracking';
import { useTheme } from '@components/commons/hooks';
import { TouchableHighlight, View } from 'react-native';

const ListItemWrapper = ({ dense, ...props }) => (
  <Box
    px={4}
    py={dense ? 3 : 24}
    flexDirection="row"
    alignItems="center"
    {...props}
  />
);

const ListItemLeftIcon = props => <Box marginRight={3} {...props} />;
const ListItemContent = props => <Box flex={1} {...props} />;
const ListItemRightIcon = props => <Box marginLeft={3} {...props} />;

const ListItem = ({
  leftIcon,
  rightIcon,
  children,
  onPress,
  bg,
  withFullDivider,
  dense,
  accessibilityLabel,
  leftIconAccessibilityLabel,
}) => {
  const theme = useTheme();

  const ListItemContainer = onPress ? TouchableHighlight : View;
  const underlayColor = theme.colors.touchableOverlayColor;
  const containerProps = {
    accessibilityLabel,
    underlayColor,
    onPress,
  };

  return (
    <ListItemContainer {...containerProps}>
      <>
        <ListItemWrapper dense={dense} bg={bg}>
          {leftIcon && (
            <ListItemLeftIcon accessibilityLabel={leftIconAccessibilityLabel}>
              {leftIcon}
            </ListItemLeftIcon>
          )}
          <ListItemContent>{children}</ListItemContent>
          {rightIcon && <ListItemRightIcon>{rightIcon}</ListItemRightIcon>}
        </ListItemWrapper>
        <Divider full={withFullDivider} />
      </>
    </ListItemContainer>
  );
};

ListItem.propTypes = {
  bg: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
  children: PropTypes.node.isRequired,
  onPress: PropTypes.func,
};

export const TrackedListItem = withTracking(ListItem);
export default ListItem;
