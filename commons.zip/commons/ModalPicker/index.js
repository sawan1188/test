/* istanbul ignore file */
import React, { useState } from 'react';
import {
  Platform,
  StyleSheet,
  TouchableOpacity,
  Picker as RNPicker,
  Modal,
  TouchableHighlight,
  TouchableNativeFeedback,
  FlatList,
} from 'react-native';

import { Text, Box } from '@components/commons';
import { useIntl, useTheme } from '@components/commons/hooks';

import PropTypes from 'prop-types';

const Picker = ({ options, field, onConfirm, title }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [item, setItem] = useState(options[0]);
  const theme = useTheme();
  const intl = useIntl();

  const renderPickerIOS = () => {
    return (
      <>
        <TouchableOpacity
          style={styles.opacityArea}
          onPress={() => setIsVisible(false)}
        />
        <Box
          position={'absolute'}
          zIndex={999}
          bottom={0}
          left={0}
          width={'100%'}
        >
          <Box
            bg={theme.colors.gray[10]}
            py={2}
            flexDirection={'row'}
            justifyContent={'space-between'}
          >
            <Box>
              <TouchableOpacity onPress={() => setIsVisible(false)}>
                <Text
                  fontSize={16}
                  textAlign={'left'}
                  lineHeight={18}
                  color={theme.colors.blue[0]}
                  paddingLeft={10}
                >
                  {intl.formatMessage({ id: 'cancel' })}
                </Text>
              </TouchableOpacity>
            </Box>
            <Box>
              <Text
                fontSize={18}
                textAlign="center"
                lineHeight={18}
                color={theme.colors.gray[0]}
              >
                {title || 'Select Gender'}
              </Text>
            </Box>
            <Box>
              <TouchableOpacity
                onPress={() => {
                  onConfirm && onConfirm(item);
                  setIsVisible(false);
                }}
              >
                <Text
                  fontSize={16}
                  textAlign={'right'}
                  lineHeight={18}
                  color={theme.colors.blue[0]}
                  paddingRight={10}
                >
                  {intl.formatMessage({ id: 'done' })}
                </Text>
              </TouchableOpacity>
            </Box>
          </Box>
          <RNPicker
            selectedValue={item.i18nId}
            style={styles.containerSelect}
            onValueChange={(itemValue, index) => {
              setItem(options[index]);
            }}
          >
            {options.length &&
              options.map(item => (
                <RNPicker.Item
                  key={item.i18nId}
                  label={intl.formatMessage({
                    id: item.i18nId,
                    defaultMessage: item.defaultLabel,
                  })}
                  value={item.value || item.i18nId}
                />
              ))}
          </RNPicker>
        </Box>
      </>
    );
  };

  const renderPickerAndroid = () => {
    return (
      <>
        <TouchableOpacity
          style={styles.opacityAreaAndroid}
          onPress={() => setIsVisible(false)}
        >
          <TouchableHighlight style={styles.containerDropAndroid}>
            <Box>
              <Text ml={2} fontSize={12} color="gray.4">
                {title || 'Gender Picker'}
              </Text>
              <Box height={1} borderBottomWidth={1} borderColor="gray.5" />
              {options.length && (
                <FlatList
                  data={options}
                  style={styles.flatList}
                  keyExtractor={item => item.i18nId}
                  renderItem={({ item }) => (
                    <TouchableNativeFeedback
                      background={TouchableNativeFeedback.Ripple('gray')}
                      onPress={() => {
                        onConfirm && onConfirm(item);
                        setIsVisible(false);
                      }}
                    >
                      <Box height={40} px={2} justifyContent="center">
                        <Text fontSize={14}>
                          {intl.formatMessage({
                            id: item.i18nId,
                            defaultMessage: item.defaultLabel,
                          })}
                        </Text>
                      </Box>
                    </TouchableNativeFeedback>
                  )}
                />
              )}
            </Box>
          </TouchableHighlight>
        </TouchableOpacity>
      </>
    );
  };

  return (
    <Box flex={1}>
      <>{field({ setIsVisible })}</>
      {isVisible && (
        <Modal
          transparent={true}
          visible={isVisible}
          onRequestClose={() => {
            onConfirm && onConfirm(item);
          }}
        >
          <Box flex={1}>
            {Platform.OS === 'ios' ? renderPickerIOS() : renderPickerAndroid()}
          </Box>
        </Modal>
      )}
    </Box>
  );
};

Picker.propTypes = {
  field: PropTypes.func.isRequired,
  onCancel: PropTypes.func,
  onConfirm: PropTypes.func,
};

export default Picker;

const styles = StyleSheet.create({
  flatList: { maxHeight: '95%' },
  opacityArea: {
    flex: 1,
    backgroundColor: 'black',
    opacity: 0.4,
  },
  opacityAreaAndroid: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  containerDropAndroid: {
    width: '90%',
    backgroundColor: '#fff',
    minHeight: '10%',
    maxHeight: '90%',
  },
  containerSelect: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    flex: 1,
  },
});
