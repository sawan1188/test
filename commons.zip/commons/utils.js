export function setRefs(...refs) {
  return function setRef(el) {
    refs.forEach(ref => {
      if (typeof ref === 'function') {
        ref(el);
      } else if (ref && ref.hasOwnProperty('current')) {
        ref.current = el;
      }
    });
  };
}

export const runValidations = validationArray => (...args) => {
  for (let i = 0; i < validationArray.length; i++) {
    const result = validationArray[i](...args);
    if (result) return result;
  }
  return '';
};
