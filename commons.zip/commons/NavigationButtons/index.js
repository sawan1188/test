import React from 'react';
import { View, Platform, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import theme from '@theme';
import PropTypes from 'prop-types';
import Box from '../Box';
import Text from '../Text';
import Image from '../Image';
import { useIntl } from '../hooks';

const platformLeftStyle = Platform.OS === 'ios' ? { paddingLeft: 15 } : {};

const StackBackButton = ({ style, icName = 'arrow-back' }) => (
  <View style={{ ...platformLeftStyle, ...style }}>
    <Icon size={24} name={icName} color={theme.colors.gray[1]} />
  </View>
);
StackBackButton.propTypes = {
  style: PropTypes.shape({
    paddingLeft: PropTypes.number,
  }),
};

const ModalBackButton = () => (
  <View style={{ ...platformLeftStyle }}>
    <Icon size={24} name="close" color={theme.colors.gray[1]} />
  </View>
);

const HeaderButton = ({ icon, ...props }) => (
  <View style={{ paddingRight: 15 }}>
    <Icon size={24} name={icon} color={theme.colors.gray[1]} {...props} />
  </View>
);
HeaderButton.propTypes = {
  icon: PropTypes.string.isRequired,
  type: PropTypes.string,
};

const HiDocHeaderText = () => {
  let intl = useIntl();
  return (
    <Text fontSize={theme.fontSizes[0]} color={theme.colors.gray[8]}>
      {intl.formatMessage({
        id: 'hidoc.poweredBy',
        defaultMessage: 'Powered by',
      })}
    </Text>
  );
};
const HidocHeaderLogo = ({ logoImage }) => {
  return (
    <Image resize="contain" ml={2} height={24} width={60} source={logoImage} />
  );
};

const HiDocHeaderRightLogo = ({ logoImage }) => {
  return (
    <Box pr={16} flexDirection={'row'}>
      <HiDocHeaderText />
      <HidocHeaderLogo logoImage={logoImage} />
    </Box>
  );
};

const HiDocHeaderCrossButton = ({ onPress, icImage }) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <Image
        ml={2}
        mr={16}
        resizeMode="contain"
        source={icImage}
        width={24}
        height={24}
      />
    </TouchableOpacity>
  );
};

const HiDocHeaderSquaresButton = ({ onPress, icImage }) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <Image
        ml={2}
        mr={16}
        resizeMode="contain"
        source={icImage}
        width={24}
        height={24}
      />
    </TouchableOpacity>
  );
};
HiDocHeaderSquaresButton.propTypes = {
  onPress: PropTypes.func.isRequired,
};

const HiDocHeaderRightComponents = ({ onPress, logoImage, icImage }) => {
  return (
    <Box flexDirection={'row'}>
      <HiDocHeaderText />
      <HidocHeaderLogo logoImage={logoImage} />
      <HiDocHeaderSquaresButton onPress={onPress} icImage={icImage} />
    </Box>
  );
};
HiDocHeaderRightComponents.propTypes = {
  onPress: PropTypes.func.isRequired,
};

export {
  StackBackButton,
  ModalBackButton,
  HeaderButton,
  HiDocHeaderRightLogo,
  HiDocHeaderCrossButton,
  HiDocHeaderSquaresButton,
  HiDocHeaderRightComponents,
};
