import React from 'react';
import { TouchableOpacity, Image } from 'react-native';
import { render } from 'react-native-testing-library';

import {
  fireEvent,
  flushMicrotasksQueue,
  act,
} from 'react-native-testing-library';

import {
  StackBackButton,
  ModalBackButton,
  HeaderButton,
  HiDocHeaderRightLogo,
  HiDocHeaderSquaresButton,
  HiDocHeaderRightComponents,
} from '@components/commons';

jest.mock('@components/commons/hooks', () => ({
  useIntl: jest.fn(() => ({
    formatMessage: jest.fn(),
  })),
}));

describe('Navigation back buttons', () => {
  it('should render StackBackButton', () => {
    const button = render(<StackBackButton />);
    // expect(button.toJSON()).toMatchSnapshot();
  });

  it('should render ModalBackButton', () => {
    const button = render(<ModalBackButton />);
    // expect(button.toJSON()).toMatchSnapshot();
  });

  it('should render HeaderButton', () => {
    const button = render(<HeaderButton icon="delete" />);
    // expect(button.toJSON()).toMatchSnapshot();
  });
});

// describe('HiDoc Navigations', () => {
//   it('should render image in squares button', () => {
//     const squaresButton = render(
//       <HiDocHeaderSquaresButton onPress={() => {}} />,
//     );
//     const squaresImage = squaresButton.getByType('Image');
//     expect(squaresImage).toBeDefined();
//   });

//   it('should call button press handle ', async () => {
//     const mockPressFunc = jest.fn();
//     const squaresButton = render(
//       <HiDocHeaderSquaresButton onPress={mockPressFunc} />,
//     );
//     const button = squaresButton.getByType(TouchableOpacity);
//     act(() => {
//       fireEvent.press(button);
//     });
//     await flushMicrotasksQueue();
//     expect(mockPressFunc).toHaveBeenCalled();
//   });

//   it('should render image in hidoc logo', () => {
//     const headerRightLogo = render(<HiDocHeaderRightLogo />);
//     expect(headerRightLogo.getByType(Image)).toBeDefined();
//   });

//   it('should render squares button in hidoc components', () => {
//     const headerRightComponents = render(<HiDocHeaderRightComponents />);
//     expect(
//       headerRightComponents.getByType(HiDocHeaderSquaresButton),
//     ).toBeDefined();
//   });
// });
