import { Text } from 'react-native-svg';
import { fontFamily } from 'styled-system';
import styled from 'styled-components/native';
import theme from '@theme';

const SvgText = styled(Text)`
  ${fontFamily}
`;

SvgText.defaultProps = {
  fontFamily: theme.fonts.default,
};

export { SvgText };
