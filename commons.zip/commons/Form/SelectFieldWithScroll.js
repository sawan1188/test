import PropTypes from 'prop-types';
import React from 'react';
import { Field } from 'redux-form';
import { injectIntl } from 'react-intl';
import { Box, Text } from '@components/commons';
import styled, { withTheme } from 'styled-components/native';
import { TouchableOpacity } from 'react-native';
import { ScrollIntoView } from 'react-native-scroll-into-view';

const Wrapper = styled(Box)`
  height: 100px;
`;

const InputWrapper = styled(Box)`
  height: 56px;
  padding-left: 16px;
  padding-right: 30px;
  justify-content: center;
  border-radius: 4px;
  ${({ theme }) => `
  color: ${theme.inputField.inputText}
  border: 1px solid ${theme.inputField.inputBorderUntouched}
  `};

  ${({ theme, disabled }) =>
    disabled && `border: 1px solid ${theme.inputField.disabledBorder}`}
  ${({ theme, error }) => error && `border: 2px solid ${theme.colors.error[0]}`}
`;

const LabelEmpty = styled(Text)`
  ${({ theme, disabled }) =>
    disabled
      ? `color: ${theme.inputField.disabledText}`
      : `color: ${theme.colors.gray[1]}`};
  font-size: 18px;
`;

const LabelWrapper = styled(Text)`
  position: absolute;
  top: -9;
  left: 16;
  padding-left: 3;
  padding-right: 3;
  border-radius: 4;
  font-size: 12px;
  line-height: 16px;
  ${({ theme }) => `
    color: ${theme.inputField.inputBorder}
    background-color: ${theme.backgroundColor.default}
  `};
`;

const ErrorText = styled.Text`
  position: absolute;
  top: 60;
  left: 16;
  font-size: 12px;
  ${({ theme }) => `
  color: ${theme.colors.error[0]}
`};
`;
const HintText = styled.Text`
  margin: 4px;
  position: absolute;
  top: 60;
  left: 16;
  font-size: 12px;
  ${({ theme }) => {
    return `color: ${theme.colors.gray[1]}`;
  }};
`;

const OnRightBox = styled(Box)`
  position: absolute;
  right: 0;
  padding-right: 10px;
  top: 0;
  height: 56px;
  display: flex;
  justify-content: center;
`;

export class CustomSelectField extends React.Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
  }

  render() {
    const {
      input: { value },
      label,
      onPress,
      hint,
      onRight,
      theme,
      disabled,
      meta: { error, touched },
      intl,
      submitCount,
    } = this.props;

    const hasValue = !!value;

    const onRightColor = () => {
      if (disabled) return theme.inputField.disabledBorder;
      return hasValue ? theme.inputField.inputBorder : theme.colors.gray[1];
    };

    const getAccessibilityLabel = () => {
      if (!label) {
        return intl.formatMessage(
          {
            id: 'selectField.accessibility.nolabel',
          },
          {
            selection: hasValue
              ? value
              : intl.formatMessage({
                  id: 'selectField.accessibility.emptyselection',
                }),
          },
        );
      }
      return intl.formatMessage(
        {
          id: 'selectField.accessibility.label',
        },
        {
          label,
          selection: hasValue
            ? value
            : intl.formatMessage({
                id: 'selectField.accessibility.emptyselection',
              }),
        },
      );
    };

    return (
      <ScrollIntoView
        enabled={!!error && !!touched}
        scrollIntoViewKey={submitCount}
        align="center"
      >
        <Wrapper>
          <TouchableOpacity
            disabled={disabled}
            onPress={onPress}
            // TODO: enable this on RN v0.60.x
            // accessibilityRole="combobox"
            accessibilityStates={[
              hasValue && 'selected',
              disabled && 'disabled',
            ].filter(Boolean)}
            accessibilityLabel={getAccessibilityLabel()}
          >
            <InputWrapper
              hasValue={hasValue}
              disabled={disabled}
              error={error && touched}
            >
              {label === undefined ? (
                <LabelEmpty disabled={disabled}>{value}</LabelEmpty>
              ) : hasValue ? (
                <React.Fragment>
                  <LabelWrapper>{label}</LabelWrapper>
                  <Text numberOfLines={1} fontSize={18} color="gray.0">
                    {value}
                  </Text>
                </React.Fragment>
              ) : (
                <LabelEmpty disabled={disabled}>{label}</LabelEmpty>
              )}
              <OnRightBox>
                {onRight &&
                  onRight({
                    color: onRightColor(),
                  })}
              </OnRightBox>
            </InputWrapper>
            {error && touched ? (
              <ErrorText>{intl.formatMessage({ id: error })}</ErrorText>
            ) : (
              hint && <HintText>{hint}</HintText>
            )}
          </TouchableOpacity>
        </Wrapper>
      </ScrollIntoView>
    );
  }
}

CustomSelectField.propTypes = {
  input: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onChange: PropTypes.func,
  }),
  onPress: PropTypes.func,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  hint: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  onRight: PropTypes.func,
  theme: PropTypes.shape({}),
  disabled: PropTypes.bool,
  meta: PropTypes.shape({
    error: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
    touched: PropTypes.bool,
  }),
  intl: PropTypes.shape({ formatMessage: PropTypes.func }),
  submitCount: PropTypes.number,
};

const SelectField = props => {
  return <Field {...props} component={CustomSelectField} />;
};

export default injectIntl(withTheme(SelectField));
