import PropTypes from 'prop-types';
import React from 'react';
import { Field } from 'redux-form';
import { TouchableWithoutFeedback, View } from 'react-native';
import { Flex, Box, Text } from '@components/commons';
import { CheckBox } from 'react-native-elements';
import styled from 'styled-components/native';
import { useTheme, useIntl } from '@components/commons/hooks';
import { ScrollIntoView } from 'react-native-scroll-into-view';

export const QuestionText = styled(Text)`
  ${({ theme }) => `
    color: ${theme.colors.gray[0]}
    font-size: ${theme.fontSizes[2]}    
  `};
  line-height: 22;
`;

const OptionText = styled(Text)`
  ${({ theme }) => `
    color: ${theme.colors.gray[8]}
    font-size: ${theme.fontSizes[2]}    
  `};
  line-height: 22;
`;

export const ErrorText = styled(Text)`
  ${({ theme }) => `
    color: ${theme.colors.error[0]}
    font-size: ${theme.fontSizes[2]}    
  `};
  line-height: 22;
`;

export const CustomRadioButtonGroup = props => {
  const intl = useIntl();
  const theme = useTheme();
  const {
    input: { value, onChange, ...restInput },
    label,
    withContainer,
    options,
    name,
    submitCount,
    meta: { error, touched },
    ...restProps
  } = props;
  const renderCheckbox = (optionValue, optionLabel, name) => {
    return (
      <TouchableWithoutFeedback
        key={name + optionValue}
        onPress={() => {
          onChange(optionValue);
        }}
        accessibilityLabel={optionLabel}
      >
        <Flex
          style={{ marginLeft: -20 }}
          as={View}
          flexDirection="row"
          alignItems="flex-start"
        >
          <CheckBox
            name={name}
            style={{ paddingLeft: 0, marginLeft: 0 }}
            checkedIcon="dot-circle-o"
            uncheckedIcon="circle-o"
            checked={optionValue == value}
            checkedColor={theme.radioButton.checked}
            {...restInput}
            {...restProps}
            onPress={() => {
              onChange(optionValue);
            }}
          />

          <Box flex={1} paddingRight={10} mt={14}>
            <OptionText accessibilityLabel={optionLabel}>
              {optionLabel}
            </OptionText>
          </Box>
        </Flex>
      </TouchableWithoutFeedback>
    );
  };

  return (
    <ScrollIntoView
      enabled={!!error && !!touched}
      scrollIntoViewKey={submitCount}
      align="center"
    >
      <Box mt={10} mb={10}>
        <QuestionText accessibilityLabel={label}>{label}</QuestionText>
      </Box>
      {error && touched ? (
        <ErrorText>{intl.formatMessage({ id: 'requiredQuestion' })}</ErrorText>
      ) : null}
      {options.map(option => {
        return renderCheckbox(option.value, option.label, name);
      })}
    </ScrollIntoView>
  );
};

CustomRadioButtonGroup.propTypes = {
  label: PropTypes.string,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      value: PropTypes.string,
    }),
  ),
  name: PropTypes.string,
  submitCount: PropTypes.number.isRequired,
};

const RadioButtonGroup = props => {
  return <Field {...props} component={CustomRadioButtonGroup} />;
};

export default RadioButtonGroup;
