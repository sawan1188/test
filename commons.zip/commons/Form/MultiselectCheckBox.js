import { Field } from 'redux-form';
import { Image, View } from 'react-native';
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
  TrackedButton,
  ListItem,
  SectionHeadingText,
  Box,
  Flex,
  Footer,
  Text,
} from '@components/commons';
import { CheckBox } from 'react-native-elements';
import styled from 'styled-components/native';
import { FlatList, SectionList } from 'react-native';

const OptionText = styled(Text)`
  ${({ theme }) => `
    color: ${theme.colors.gray[8]}
    font-size: ${theme.fontSizes[2]}    
  `};
`;

export const ClaimsListSectionHeader = ({ title, backgroundColor }) => (
  <Box backgroundColor={backgroundColor} px={4} pt={32} pb={8}>
    <SectionHeadingText>{title}</SectionHeadingText>
  </Box>
);

export const CustomMultiselectCheckBox = props => {
  const {
    data,
    buttonLabel,
    clearAllButtonLabel,
    clearAllButtonTrackingActionParams = null,
    submitButtonTrackingActionParams = null,
    onSubmit,
    onChange,
    isSectionList,
    bodyBackgroundColor,
  } = props;
  const [selectedValues, setSelectedValues] = useState(
    props.selectedValues || [],
  );
  const transformToSectionDataFormat = dataList => {
    let transformedData = [];
    dataList.forEach(data => {
      let isDataPresent =
        transformedData.filter(td => td.title === data.title).length > 0;
      if (!isDataPresent) {
        transformedData.push({
          title: data.title,
          titleValue: data.titleValue,
          data: [
            {
              label: data.label,
              value: data.value,
              id: data.value,
            },
          ],
        });
      } else {
        let index = transformedData.findIndex(td => td.title === data.title);
        transformedData[index].data.push({
          label: data.label,
          value: data.value,
          id: data.value,
        });
      }
    });
    return transformedData;
  };

  const checkBoxWithInversion = data.filter(item => item.hasInversion)[0];

  const doesInclude = (value, data) => {
    if (!isSectionList) return data.includes(value);
    else {
      return data.findIndex(datum => datum.value === value.value) !== -1;
    }
  };

  const updateSelectedValues = ({ value, hasInversion }) => {
    if (!isSectionList) {
      let updatedList = selectedValues;
      if (hasInversion && !doesInclude(value, selectedValues)) {
        updatedList = [value];
        return setSelectedValues(updatedList);
      }

      if (updatedList.includes(value)) {
        updatedList = updatedList.filter(item => item !== value);
        return setSelectedValues(updatedList);
      }

      updatedList = updatedList.concat(value);
      if (checkBoxWithInversion !== undefined) {
        updatedList = updatedList.filter(
          item => item != checkBoxWithInversion.value,
        );
      }
      setSelectedValues(updatedList);
    } else {
      let updatedList = selectedValues;
      if (hasInversion && !doesInclude(value, selectedValues)) {
        updatedList = [value];
        return setSelectedValues(updatedList);
      }

      if (doesInclude(value, updatedList)) {
        updatedList = updatedList.filter(item => item.value !== value.value);
        return setSelectedValues(updatedList);
      }

      updatedList = updatedList.concat(value);
      if (checkBoxWithInversion !== undefined) {
        updatedList = updatedList.filter(
          item => item.value != checkBoxWithInversion.value.value,
        );
      }
      setSelectedValues(updatedList);
    }
  };

  const renderCheckBox = item => {
    return (
      <ListItem key={item.value} onPress={() => updateSelectedValues(item)}>
        <Flex as={View} flexDirection="row" alignItems="flex-start">
          <Box flex={1} paddingRight={10}>
            <OptionText accessibilityLabel={item.label}>
              {item.label}
            </OptionText>
          </Box>
          <CheckBox
            key={item.value}
            containerStyle={{ padding: 0, margin: 0 }}
            checked={doesInclude(item.value, selectedValues)}
            onPress={() => updateSelectedValues(item)}
            checkedIcon={
              <Image source={require('../../../images/checkboxActive.png')} />
            }
            uncheckedIcon={
              <Image source={require('../../../images/checkboxInactive.png')} />
            }
          />
        </Flex>
      </ListItem>
    );
  };

  const handleSubmit = values => () => {
    onSubmit(values);
    onChange(values);
  };

  const handleClearAll = () => {
    setSelectedValues([]);
  };

  return (
    <>
      {isSectionList ? (
        <SectionList
          style={{ backgroundColor: bodyBackgroundColor }}
          sections={transformToSectionDataFormat(data)}
          extraData={selectedValues}
          keyExtractor={item => item.id}
          renderItem={({ item, section: { titleValue } }) => {
            let itemNew = {
              label: item.label,
              value: { type: titleValue, value: item.value },
            };
            return renderCheckBox(itemNew);
          }}
          renderSectionHeader={({ section: { title } }) => (
            <ClaimsListSectionHeader
              title={title}
              backgroundColor={bodyBackgroundColor}
            />
          )}
        />
      ) : (
        <FlatList
          style={{ backgroundColor: bodyBackgroundColor }}
          data={data}
          extraData={selectedValues}
          keyExtractor={item => item.id}
          renderItem={({ item }) => renderCheckBox(item)}
        />
      )}

      <Footer flexDirection="row">
        <Box flex={1} flexDirection="row">
          {clearAllButtonLabel && (
            <Box flex={1.1} flexDirection="row">
              <Box flex={1}>
                <TrackedButton
                  outline
                  onPress={handleClearAll}
                  title={clearAllButtonLabel}
                  actionParams={clearAllButtonTrackingActionParams}
                />
              </Box>
              <Box flex={0.1} />
            </Box>
          )}
          <Box flex={1}>
            <TrackedButton
              primary
              onPress={handleSubmit(selectedValues)}
              title={buttonLabel}
              actionParams={submitButtonTrackingActionParams}
            />
          </Box>
        </Box>
      </Footer>
    </>
  );
};

CustomMultiselectCheckBox.propTypes = {
  buttonLabel: PropTypes.string.isRequired,
  clearAllButtonLabel: PropTypes.string,
  clearAllButtonTrackingActionParams: PropTypes.shape({
    category: PropTypes.string,
    action: PropTypes.string,
  }),
  submitButtonTrackingActionParams: PropTypes.shape({
    category: PropTypes.string,
    action: PropTypes.string,
  }),
  data: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string,
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
      hasInversion: PropTypes.bool,
    }),
  ),
  isSectionList: PropTypes.bool,
  selectedValues: PropTypes.arrayOf(
    PropTypes.shape({
      type: PropTypes.string,
      value: PropTypes.string,
    }),
  ),
  onSubmit: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  bodyBackgroundColor: PropTypes.string,
};

const MultiselectCheckBox = props => {
  return <Field {...props} component={CustomMultiselectCheckBox} />;
};

export default MultiselectCheckBox;
