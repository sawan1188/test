import PropTypes from 'prop-types';
import React from 'react';
import { Field } from 'redux-form';
import { Image, TouchableOpacity } from 'react-native';
import { Flex, Box, Text } from '@components/commons';
import { CheckBox } from 'react-native-elements';
import styled from 'styled-components/native';
import { useTheme } from '@components/commons/hooks';

export const CheckBoxFieldText = styled(Text)`
  ${({ theme }) => `
    color: ${theme.colors.gray[0]}
    font-size: ${theme.fontSizes[2]}
  `};
  line-height: 22;
`;

export const CustomCheckBoxField = props => {
  const theme = useTheme();
  const {
    input: { value, onChange, ...restInput },
    label,
    withContainer,
    ...restProps
  } = props;

  const renderCheckboxWithContainer = () => {
    return (
      <Box
        marginTop={12}
        marginBottom={12}
        paddingTop={19}
        paddingBottom={19}
        paddingRight={24}
        borderRadius={4}
        border={
          value
            ? `1px solid ${theme.checkBox.checked}`
            : `1px solid ${theme.checkBox.unchecked}`
        }
      >
        {renderCheckbox()}
      </Box>
    );
  };

  const renderCheckbox = () => {
    return (
      <Flex
        as={TouchableOpacity}
        flexDirection="row"
        alignItems="center"
        accessibilityLabel={label}
        onPress={() => {
          onChange(!value);
        }}
      >
        <CheckBox
          checked={!!value}
          checkedIcon={
            <Image source={require('../../../images/checkboxActive.png')} />
          }
          uncheckedIcon={
            <Image source={require('../../../images/checkboxInactive.png')} />
          }
          {...restInput}
          {...restProps}
          onPress={() => {
            onChange(!value);
          }}
        />

        <Box flex={1}>
          <CheckBoxFieldText>{label}</CheckBoxFieldText>
        </Box>
      </Flex>
    );
  };

  return (
    <Box>
      {withContainer ? renderCheckboxWithContainer() : renderCheckbox()}
    </Box>
  );
};

CustomCheckBoxField.propTypes = {
  input: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    onChange: PropTypes.func,
  }),
  label: PropTypes.string,
  withContainer: PropTypes.bool,
};

const CheckBoxField = props => {
  return <Field {...props} component={CustomCheckBoxField} />;
};

export default CheckBoxField;
