import { Input } from '@components/commons';
import PropTypes from 'prop-types';
import React from 'react';
import { Field } from 'redux-form';
import { injectIntl } from 'react-intl';
import { ScrollIntoView } from 'react-native-scroll-into-view';

export class CustomInputField extends React.Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
  }

  render() {
    const {
      label,
      secureTextEntry,
      hint,
      input: { value, onChange, ...restInput },
      meta: { error, touched },
      keyboardType,
      autoCapitalize,
      returnKeyType,
      rightIcon,
      leftIcon,
      onSubmitEditing,
      editable,
      onTouchStart,
      onPress,
      intl,
      validationErrorsLocalized,
      submitCount,
      ...restProps
    } = this.props;

    const localizedError =
      error && validationErrorsLocalized
        ? error
        : error && intl.formatMessage({ id: error, defaultMessage: 'Error' });

    return (
      <ScrollIntoView
        enabled={!!error}
        scrollIntoViewKey={submitCount}
        align="center"
      >
        <Input
          {...restInput}
          {...restProps}
          ref={this.inputRef}
          hint={hint}
          label={label}
          secureTextEntry={secureTextEntry}
          onSubmitEditing={onSubmitEditing}
          onChangeText={onChange}
          value={value}
          error={localizedError}
          touched={touched}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          returnKeyType={returnKeyType}
          rightIcon={rightIcon}
          leftIcon={leftIcon}
          editable={editable}
          onTouchStart={onTouchStart}
          onPress={onPress}
          accessibilityLabel={label}
        />
      </ScrollIntoView>
    );
  }
}

CustomInputField.propTypes = {
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  secureTextEntry: PropTypes.bool,
  hint: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  keyboardType: PropTypes.string,
  autoCapitalize: PropTypes.string,
  returnKeyType: PropTypes.string,
  rightIcon: PropTypes.node,
  leftIcon: PropTypes.node,
  input: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onChange: PropTypes.func,
  }),
  meta: PropTypes.shape({
    error: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
    touched: PropTypes.bool,
  }),
  onSubmitEditing: PropTypes.func,
  onTouchStart: PropTypes.func,
  editable: PropTypes.bool,
  onPress: PropTypes.func,
  intl: PropTypes.shape({ formatMessage: PropTypes.func }),
  accessibilityLabel: PropTypes.string,
  validationErrorsLocalized: PropTypes.bool,
  submitCount: PropTypes.number,
};

const InputField = React.forwardRef((props, ref) => {
  return <Field forwardRef ref={ref} {...props} component={CustomInputField} />;
});

export const focusField = ref => {
  ref.current._wrappedInstance.ref.current
    .getRenderedComponent()
    .inputRef.current.focus();
};

export default injectIntl(InputField, { withRef: true });
