import React from 'react';
import { CustomInputField } from '../InputFieldWithScroll';
import { renderForTest } from '@testUtils';

describe('CustomInputField', () => {
  it('should render correctly', () => {
    const props = {
      label: 'Label',
      secureTextEntry: false,
      hint: 'hint',
      keyboardType: 'keyboardType',
      autoCapitalize: 'autoCapitalize',
      returnKeyType: 'returnKeyType',
      rightIcon: null,
      leftIcon: null,
      input: {
        value: 'value',
        onChange: () => {},
      },
      meta: {
        error: 'meta error',
        touched: false,
      },
      onSubmitEditing: () => {},
      onTouchStart: () => {},
      editable: false,
      onPress: () => {},
      intl: { formatMessage: () => {} },
      accessibilityLabel: 'accessibility label',
      validationErrorsLocalized: false,
      submitCount: 1,
    };

    const component = renderForTest(<CustomInputField {...props} />);

    expect(component).toBeDefined();
  });
});
