import {
  ClaimsListSectionHeader,
  CustomMultiselectCheckBox as MultiSelectCheckBox,
} from '../MultiselectCheckBox';
import { renderForTest } from '@testUtils';
import { CheckBox } from 'react-native-elements';
import { FlatList, SectionList } from 'react-native';
import React from 'react';
import { Button, ListItem } from '@components/commons';
import {
  fireEvent,
  flushMicrotasksQueue,
  act,
} from 'react-native-testing-library';

describe('MultiSelectCheckBox', () => {
  const dataWithoutInversion = [
    {
      label: 'item 1',
      value: 'item1',
    },
    {
      label: 'item 2',
      value: 'item2',
    },
  ];

  const dataWithInversion = [
    {
      label: 'item 1',
      value: 'item1',
    },
    {
      label: 'item 2',
      value: 'item2',
    },
    {
      label: 'item 3',
      value: 'item3',
      hasInversion: true,
    },
  ];
  it('should render the checkboxes and button', () => {
    const props = {
      data: dataWithoutInversion,
      selectedValues: ['item2'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    var flatList = component.queryAllByType(FlatList);
    var checkBoxes = component.queryAllByType(CheckBox);

    expect(flatList.length).toBe(1);
    expect(component.queryAllByType(ListItem).length).toBe(2);

    expect(checkBoxes).toBeDefined();
    expect(checkBoxes.length).toBe(2);

    expect(checkBoxes[0].props.checked).toBe(false);
    expect(checkBoxes[1].props.checked).toBe(true);

    var button = component.getAllByType(Button);

    expect(button).toBeDefined();
    expect(button.length).toBe(1);

    expect(button[0].props.title).toBe(props.buttonLabel);
  });

  it('should render the section list when isSectionList is true', () => {
    const props = {
      data: dataWithoutInversion,
      selectedValues: ['item2'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
      isSectionList: true,
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    expect(component.queryAllByType(SectionList).length).toBe(1);
    expect(component.queryAllByType(FlatList).length).toBe(0);
  });

  it('should render the section header when isSectionList is true', () => {
    const dataWithHeaders = [
      {
        title: 'header 1',
        label: 'item 1',
        value: 'item1',
      },
      {
        title: 'header 1',
        label: 'item 2',
        value: 'item2',
      },
      {
        title: 'header 2',
        label: 'item 2',
        value: 'item2',
      },
    ];

    const props = {
      data: dataWithHeaders,
      selectedValues: ['item2'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
      isSectionList: true,
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    expect(component.queryAllByText('header 1').length).toBe(1);
    expect(component.queryAllByText('header 2').length).toBe(1);
  });

  it('should render unchecked boxes without selectedValues', () => {
    const props = {
      data: dataWithoutInversion,
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);
    var checkBoxes = component.getAllByType(CheckBox);

    expect(checkBoxes[0].props.checked).toBe(false);
    expect(checkBoxes[1].props.checked).toBe(false);
  });

  it('should update the selected values on button click', async () => {
    const props = {
      data: dataWithoutInversion,
      selectedValues: ['item2'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    var checkBoxes = component.getAllByType(CheckBox);

    fireEvent.press(checkBoxes[0]);
    fireEvent.press(checkBoxes[1]);

    var button = component.getByType(Button);

    fireEvent.press(button);

    expect(props.onSubmit).toHaveBeenCalledWith([props.data[0].value]);
    expect(props.onChange).toHaveBeenCalledWith([props.data[0].value]);
  });

  it('should unselect all the checkboxes if a checkbox with inversion is clicked', async () => {
    const props = {
      data: dataWithInversion,
      selectedValues: [],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    var checkBoxes = component.getAllByType(CheckBox);

    fireEvent.press(checkBoxes[0]);
    fireEvent.press(checkBoxes[1]);

    var button = component.getByType(Button);

    fireEvent.press(button);

    expect(props.onSubmit).toHaveBeenCalledWith([
      props.data[0].value,
      props.data[1].value,
    ]);
    expect(props.onChange).toHaveBeenCalledWith([
      props.data[0].value,
      props.data[1].value,
    ]);

    fireEvent.press(checkBoxes[2]);

    fireEvent.press(button);

    expect(props.onSubmit).toHaveBeenCalledWith([props.data[2].value]);
    expect(props.onChange).toHaveBeenCalledWith([props.data[2].value]);
  });

  it('should unselect inversion checkbox when another checkbox is clicked after inversion is checked', async () => {
    const props = {
      data: dataWithInversion,
      selectedValues: ['item1'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    var checkBoxes = component.getAllByType(CheckBox);

    fireEvent.press(checkBoxes[2]);

    var button = component.getByType(Button);

    fireEvent.press(button);

    expect(props.onSubmit).toHaveBeenCalledWith([props.data[2].value]);
    expect(props.onChange).toHaveBeenCalledWith([props.data[2].value]);

    fireEvent.press(checkBoxes[1]);
    fireEvent.press(button);

    expect(props.onSubmit).toHaveBeenCalledWith([props.data[1].value]);
    expect(props.onChange).toHaveBeenCalledWith([props.data[1].value]);
  });

  it('should unchecked inversion checkbox', async () => {
    const props = {
      data: dataWithInversion,
      selectedValues: ['item3'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);

    var checkBoxes = component.getAllByType(CheckBox);

    fireEvent.press(checkBoxes[2]);

    var button = component.getByType(Button);

    fireEvent.press(button);

    expect(props.onSubmit).toHaveBeenCalledWith([]);
  });

  it('should check or uncheck boxes when listItem is clicked', () => {
    const props = {
      data: dataWithoutInversion,
      selectedValues: ['item2'],
      buttonLabel: 'some Label',
      onSubmit: jest.fn(),
      onChange: jest.fn(),
    };

    const component = renderForTest(<MultiSelectCheckBox {...props} />);
    const tiles = component.getAllByType(ListItem);
    const checkBoxes = component.getAllByType(CheckBox);

    expect(checkBoxes[0].props.checked).toBe(false);
    expect(checkBoxes[1].props.checked).toBe(true);

    fireEvent.press(tiles[0]);
    fireEvent.press(tiles[1]);

    expect(checkBoxes[1].props.checked).toBe(false);
    expect(checkBoxes[0].props.checked).toBe(true);
  });

  describe('Clear all button', () => {
    it('should be rendered when clearAllLabel prop is set', () => {
      const props = {
        data: dataWithoutInversion,
        selectedValues: [],
        buttonLabel: 'some Label',
        clearAllButtonLabel: 'Clear All',
        onSubmit: jest.fn(),
        onChange: jest.fn(),
      };

      const component = renderForTest(<MultiSelectCheckBox {...props} />);
      const buttons = component.queryAllByType(Button);

      expect(buttons.length).toBe(2);
      expect(buttons[0].props.title).toBe('Clear All');
    });

    it('should not be rendered when clearAllLabel prop is not set', () => {
      const props = {
        data: dataWithoutInversion,
        selectedValues: [],
        buttonLabel: 'some Label',
        onSubmit: jest.fn(),
        onChange: jest.fn(),
      };

      const component = renderForTest(<MultiSelectCheckBox {...props} />);
      const buttons = component.queryAllByType(Button);

      expect(buttons.length).toBe(1);
      expect(buttons[0].props.title).toBe('some Label');
    });

    it('should clear all selected values on press', async () => {
      const props = {
        data: dataWithoutInversion,
        selectedValues: [dataWithoutInversion[0].value],
        buttonLabel: 'some Label',
        clearAllButtonLabel: 'Clear All',
        onSubmit: jest.fn(),
        onChange: jest.fn(),
      };

      const component = renderForTest(<MultiSelectCheckBox {...props} />);
      const clearAllButton = component.queryAllByType(Button)[0];

      act(() => {
        fireEvent.press(clearAllButton);
      });
      await flushMicrotasksQueue();

      const submitButton = component.queryAllByType(Button)[1];

      act(() => {
        fireEvent.press(submitButton);
      });
      await flushMicrotasksQueue();

      expect(props.onSubmit).toHaveBeenCalledWith([]);
    });
  });

  describe('BodyBackgroundColor', () => {
    it('should apply bodyBackgroundColor to flatlist', () => {
      const color = 'black';
      const props = {
        bodyBackgroundColor: color,
        data: dataWithoutInversion,
        selectedValues: [dataWithoutInversion[0].value],
        buttonLabel: 'some Label',
        clearAllButtonLabel: 'Clear All',
        onSubmit: jest.fn(),
        onChange: jest.fn(),
      };

      const component = renderForTest(<MultiSelectCheckBox {...props} />);

      expect(
        component.queryAllByType(FlatList)[0].props.style.backgroundColor,
      ).toBe(color);
    });

    it('should apply bodyBackgroundColor to sectionlist', () => {
      const color = 'black';
      const props = {
        bodyBackgroundColor: color,
        data: dataWithoutInversion,
        selectedValues: ['item2'],
        buttonLabel: 'some Label',
        onSubmit: jest.fn(),
        onChange: jest.fn(),
        isSectionList: true,
      };

      const component = renderForTest(<MultiSelectCheckBox {...props} />);

      let sectionList = component.queryAllByType(SectionList)[0];
      expect(sectionList.props.style.backgroundColor).toBe(color);

      expect(
        component.queryAllByType(ClaimsListSectionHeader)[0].props
          .backgroundColor,
      ).toBe(color);
    });
  });
});
