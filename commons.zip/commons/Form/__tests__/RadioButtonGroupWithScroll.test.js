import React from 'react';
import { TouchableWithoutFeedback } from 'react-native';
import { fireEvent, act } from 'react-native-testing-library';
import { ScrollIntoView } from 'react-native-scroll-into-view';
import { renderForTest } from '@testUtils';
import { CustomRadioButtonGroup } from '../RadioButtonGroupWithScroll';
import { CheckBox } from 'react-native-elements';
import theme from '@theme';
import messages from '@messages/en-HK.json';

let Component, ComponentItems;

const props = {
  input: {
    value: 'foo',
    onChange: jest.fn(),
  },
  submitCount: 1,
  theme,
  meta: {
    error: '',
    touched: false,
  },
  options: [
    { value: 'value1', label: 'label1', name: 'name1' },
    { value: 'value2', label: 'label2', name: 'name2' },
  ],
};

describe('RadioButtonGroupWithScroll', () => {
  beforeAll(() => {
    Component = renderForTest(<CustomRadioButtonGroup {...props} />);
    ComponentItems = Component.getAllByType(TouchableWithoutFeedback);
  });
  beforeEach(() => jest.clearAllMocks());

  it('should render a scrollIntoView', () => {
    const component = renderForTest(<CustomRadioButtonGroup {...props} />);

    expect(component.queryByType(ScrollIntoView)).toBeDefined();
  });

  test('renders error state correctly', () => {
    const meta = { error: 'foo', touched: true };
    const component = renderForTest(
      <CustomRadioButtonGroup {...props} meta={meta} />,
    );
    // expect(component.toJSON()).toMatchSnapshot();
  });

  test('should render error when error and touched', () => {
    const meta = { error: true, touched: true };
    const component = renderForTest(
      <CustomRadioButtonGroup {...props} meta={meta} />,
    );
    const ErrorText = component.queryAllByText(messages.requiredQuestion);
    expect(ErrorText).toHaveLength(1);
  });

  test('should not render error when error but not touch', () => {
    const meta = { error: true, touched: false };
    const component = renderForTest(
      <CustomRadioButtonGroup {...props} meta={meta} />,
    );
    const ErrorText = component.queryAllByText(messages.requiredQuestion);
    expect(ErrorText).toHaveLength(0);
  });

  test('should not render error when touch but not error', () => {
    const meta = { error: false, touched: true };
    const component = renderForTest(
      <CustomRadioButtonGroup {...props} meta={meta} />,
    );
    const ErrorText = component.queryAllByText(messages.requiredQuestion);
    expect(ErrorText).toHaveLength(0);
  });

  test('should render all componentItem', () => {
    expect(ComponentItems).toHaveLength(props.options.length);
  });

  test('should change value when click item', () => {
    act(() => {
      fireEvent.press(ComponentItems[0]);
    });
    expect(props.input.onChange).toHaveBeenCalled();
  });

  test('should change value when click Checkbox item', () => {
    const CheckBoxes = Component.queryAllByType(CheckBox);
    act(() => {
      CheckBoxes.forEach(CheckBox => {
        fireEvent(CheckBox, 'click');
      });
    });
    expect(props.input.onChange).toHaveBeenCalledTimes(CheckBoxes.length);
  });
});
