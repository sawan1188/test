import { renderForTest } from '@testUtils';
import { CustomSelectField as SelectField } from '../SelectField';
import React from 'react';
import { Icon } from 'react-native-elements';
import theme from '@theme';

const props = {
  input: {
    value: 'foo',
  },
  onRight: ({ color }) => <Icon name="event" color={color} />,
  theme,
  meta: {
    error: '',
    touched: false,
  },
  intl: {
    formatMessage: jest.fn(() => 'foo'),
  },
  label: 'label',
};

describe('SelectField', () => {
  it('renders disabled state correctly', () => {
    const component = renderForTest(<SelectField {...props} disabled />);
    // expect(component.toJSON()).toMatchSnapshot();
  });

  it('renders error state correctly', () => {
    const meta = { error: 'foo', touched: true };
    const component = renderForTest(<SelectField {...props} meta={meta} />);
    // expect(component.toJSON()).toMatchSnapshot();
  });

  it('renders state without label correctly', () => {
    const props = {
      input: {
        value: 'foo',
      },
      onRight: ({ color }) => <Icon name="event" color={color} />,
      theme,
      meta: {
        error: '',
        touched: false,
      },
      intl: {
        formatMessage: jest.fn(() => 'foo'),
      },
    };

    const component = renderForTest(<SelectField {...props} />);
    // expect(component.toJSON()).toMatchSnapshot();
  });
});
