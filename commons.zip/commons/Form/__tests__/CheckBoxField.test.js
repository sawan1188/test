import React from 'react';
import { Flex } from '@components/commons';
import {
  CheckBoxFieldText,
  CustomCheckBoxField as CheckBoxField,
} from '../CheckBoxField';
import { renderForTest } from '@testUtils';
import { CheckBox } from 'react-native-elements';
import { fireEvent } from 'react-native-testing-library';

describe('CustomCheckBoxField', () => {
  it('should render checkbox field', () => {
    const props = {
      label: 'Some Label',
      withContainer: false,
      input: {
        value: 'The value of the checkbox',
        onChange: jest.fn(),
      },
    };

    const component = renderForTest(<CheckBoxField {...props} />);
    const checkboxField = component.queryAllByType(CheckBox);

    expect(checkboxField).toBeDefined();
  });

  it('should render checkbox field text with Some Label', () => {
    const props = {
      label: 'Some Label',
      withContainer: false,
      input: {
        value: 'The value of the checkbox',
        onChange: jest.fn(),
      },
    };

    const component = renderForTest(<CheckBoxField {...props} />);
    const checkboxFieldText = component.queryAllByType(CheckBoxFieldText);

    expect(checkboxFieldText[0].props.children).toEqual(props.label);
  });

  it('should render checkbox with container', () => {
    const props = {
      label: 'Some Label',
      withContainer: true,
      input: {
        value: 'The value of the checkbox',
        onChange: jest.fn(),
      },
    };

    const component = renderForTest(<CheckBoxField {...props} />);
    const checkboxFieldText = component.queryAllByType(CheckBoxFieldText);

    expect(checkboxFieldText[0].props.children).toEqual(props.label);
  });

  it('should call onChange when click Flex component', () => {
    const props = {
      label: 'Some Label',
      withContainer: true,
      input: {
        value: 'The value of the checkbox',
        onChange: jest.fn(),
      },
    };

    const component = renderForTest(<CheckBoxField {...props} />);
    const Flexs = component.queryAllByType(Flex);
    fireEvent(Flexs[0], 'onPress');
    expect(props.input.onChange).toHaveBeenCalledWith(!props.input.value);
  });

  it('should call onChange when click Checkbox component', () => {
    const props = {
      label: 'Some Label',
      withContainer: true,
      input: {
        value: 'The value of the checkbox',
        onChange: jest.fn(),
      },
    };

    const component = renderForTest(<CheckBoxField {...props} />);
    const CheckBoxes = component.queryAllByType(CheckBox);
    fireEvent(CheckBoxes[0], 'onPress');
    expect(props.input.onChange).toHaveBeenCalledWith(!props.input.value);
  });

  it('should render correctly with container and no value', () => {
    const props = {
      label: 'Some Label',
      withContainer: true,
      input: {
        value: null,
        onChange: jest.fn(),
      },
    };

    const component = renderForTest(<CheckBoxField {...props} />);
    const checkboxFieldText = component.queryAllByType(CheckBoxFieldText);

    expect(checkboxFieldText[0].props.children).toEqual(props.label);
  });
});
