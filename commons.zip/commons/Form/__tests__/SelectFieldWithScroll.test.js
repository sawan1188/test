import { renderForTest } from '@testUtils';
import { CustomSelectField as SelectFieldWithScroll } from '../SelectFieldWithScroll';
import React from 'react';
import { Icon } from 'react-native-elements';
import theme from '@theme';
import { ScrollIntoView } from 'react-native-scroll-into-view';

const props = {
  input: {
    value: 'foo',
    onChange: () => {},
  },
  onPress: () => {},
  label: 'label',
  hint: 'hint',
  onRight: ({ color }) => <Icon name="event" color={color} />,
  theme,
  meta: {
    error: '',
    touched: false,
  },
  intl: {
    formatMessage: jest.fn(() => 'foo'),
  },
  submitCount: 1,
};

describe('SelectFieldWithScroll', () => {
  it('renders correctly', () => {
    const component = renderForTest(<SelectFieldWithScroll {...props} />);
    // expect(component.toJSON()).toMatchSnapshot();
  });

  it('renders disabled state correctly', () => {
    const component = renderForTest(
      <SelectFieldWithScroll {...props} disabled />,
    );
    // expect(component.toJSON()).toMatchSnapshot();
  });

  it('renders error state correctly', () => {
    const meta = { error: 'foo', touched: true };
    const component = renderForTest(
      <SelectFieldWithScroll {...props} meta={meta} />,
    );
    // expect(component.toJSON()).toMatchSnapshot();
  });

  it('should render a scrollIntoView', () => {
    const component = renderForTest(<SelectFieldWithScroll {...props} />);

    expect(component.queryByType(ScrollIntoView)).toBeDefined();
  });
  it('renders state without label correctly', () => {
    const props = {
      input: {
        value: 'foo',
      },
      onRight: ({ color }) => <Icon name="event" color={color} />,
      theme,
      meta: {
        error: '',
        touched: false,
      },
      intl: {
        formatMessage: jest.fn(() => 'foo'),
      },
    };

    const component = renderForTest(<SelectFieldWithScroll {...props} />);
    // expect(component.toJSON()).toMatchSnapshot();
  });
});
