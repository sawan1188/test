import { focusField } from './InputField';
import { default as InputFieldWithScroll } from './InputFieldWithScroll';
import { default as InputFieldWithoutScroll } from './InputField';
import CheckBoxField from './CheckBoxField';
import { default as SelectFieldWithoutScroll } from './SelectField';
import { default as SelectFieldWithScroll } from './SelectFieldWithScroll';
import { default as RadioButtonGroupWithoutScroll } from './RadioButtonGroup';
import { default as RadioButtonGroupWithScroll } from './RadioButtonGroupWithScroll';
import FeatureToggle from '@config/FeatureToggle';
import MultiselectCheckBox, {
  CustomMultiselectCheckBox,
} from './MultiselectCheckBox';

let RadioButtonGroup = FeatureToggle.NO_DEFAULT_ANSWERS.on
  ? RadioButtonGroupWithScroll
  : RadioButtonGroupWithoutScroll;

let SelectField = FeatureToggle.NO_DEFAULT_ANSWERS.on
  ? SelectFieldWithScroll
  : SelectFieldWithoutScroll;

let InputField = FeatureToggle.NO_DEFAULT_ANSWERS.on
  ? InputFieldWithScroll
  : InputFieldWithoutScroll;

export {
  InputField,
  focusField,
  CheckBoxField,
  SelectField,
  RadioButtonGroup,
  MultiselectCheckBox,
  CustomMultiselectCheckBox,
};
