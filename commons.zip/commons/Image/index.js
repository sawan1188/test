import React, { useState, useEffect } from 'react';
import {
  flex,
  justifySelf,
  alignSelf,
  order,
  display,
  maxWidth,
  minWidth,
  width,
  height,
  maxHeight,
  minHeight,
  position,
  size,
  space,
  resizeMode,
  accessibilityLabel,
} from 'styled-system';
import styled from 'styled-components/native';
import api from '@services/api';

const BaseImage = styled.Image`
  ${space}
  ${flex}
  ${justifySelf}
  ${alignSelf}
  ${display}
  ${width}
  ${maxWidth}
  ${minWidth}
  ${position}
  ${height}
  ${maxHeight}
  ${minHeight}
  ${size}
  ${order}
  ${resizeMode}
  ${accessibilityLabel}
`;

const Image = React.forwardRef(({ secure, source, ...props }, ref) => {
  const [authHeaders, setAuthHeaders] = useState(null);
  useEffect(() => {
    async function fetchHeaders() {
      let authHeaders = await api.getAuthHeaders();
      setAuthHeaders(authHeaders);
    }
    fetchHeaders();
  }, []);

  const imageSource = secure
    ? authHeaders
      ? {
          ...source,
          headers: authHeaders,
        }
      : null
    : source;

  return <BaseImage ref={ref} source={imageSource} {...props} />;
});

export default Image;
