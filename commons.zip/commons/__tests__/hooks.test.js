import { act, renderHook } from '@testing-library/react-hooks';
import { flushMicrotasksQueue } from 'react-native-testing-library';
import { useFetchActions, useBackButtonHandler } from '../hooks';

import MockBackHandler from 'react-native/Libraries/Utilities/__mocks__/BackHandler';
import { BackHandler } from 'react-native';
import { useIsFocused } from '@react-navigation/native';

jest.mock(
  'react-native/Libraries/Utilities/BackHandler',
  () => MockBackHandler,
);
jest.mock('@react-navigation/native', () => ({
  useIsFocused: jest.fn(),
}));

describe('useFetchActions', () => {
  it('should handle loading state', async () => {
    const fetchActionSpy = jest.fn(() => Promise.resolve());
    const { result } = renderHook(() => useFetchActions([fetchActionSpy]));

    expect(result.current[0]).toBe(true);
    expect(result.current[1]).toBe(false);

    await flushMicrotasksQueue();

    expect(result.current[0]).toBe(false);
    expect(result.current[1]).toBe(false);
  });

  it('should handle error state', async () => {
    const fetchActionSpy = jest.fn(() => Promise.reject());
    const { result } = renderHook(() => useFetchActions([fetchActionSpy]));

    expect(result.current[0]).toBe(true);
    expect(result.current[1]).toBe(false);

    await flushMicrotasksQueue();

    expect(result.current[0]).toBe(false);
    expect(result.current[1]).toBe(true);
  });

  it('should call action with parameters if passed in', async () => {
    const fetchActionSpy1 = jest.fn();
    const fetchActionSpy2 = jest.fn();
    const param1 = { param: 'some-param1' };
    const param2 = { param: 'some-param2' };
    renderHook(() =>
      useFetchActions(
        [fetchActionSpy1, fetchActionSpy2],
        true,
        [],
        [param1, param2],
      ),
    );

    await flushMicrotasksQueue();

    expect(fetchActionSpy1).toHaveBeenCalledWith(param1);
    expect(fetchActionSpy2).toHaveBeenCalledWith(param2);
  });

  it('should call action with undefined if no parameters are passed in', async () => {
    const fetchActionSpy = jest.fn();
    renderHook(() => useFetchActions([fetchActionSpy]));

    await flushMicrotasksQueue();

    expect(fetchActionSpy).toHaveBeenCalledWith(undefined);
  });

  it('should not attempt to set state upon unmounting', async () => {
    const fetchActionSpy = jest.fn(() => Promise.resolve());
    const { result, unmount } = renderHook(() =>
      useFetchActions([fetchActionSpy]),
    );

    expect(result.current[0]).toBe(true);
    expect(result.current[1]).toBe(false);

    unmount();
    await flushMicrotasksQueue();

    expect(result.current[0]).toBe(true);
    expect(result.current[1]).toBe(false);
  });
});

describe('useBackButtonHandler', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should handle back button press and remove handler on navigation blur', () => {
    const handlerSpy = jest.fn().mockReturnValueOnce(true);
    useIsFocused.mockReturnValueOnce(true);
    const { rerender } = renderHook(() => useBackButtonHandler(handlerSpy));

    BackHandler.mockPressBack();
    expect(handlerSpy).toHaveBeenCalledTimes(1);

    useIsFocused.mockReturnValueOnce(false);
    rerender();

    BackHandler.mockPressBack();

    expect(BackHandler.exitApp).toHaveBeenCalledTimes(1);
  });

  it('should remove handler on unmount', () => {
    const handlerSpy = jest.fn().mockReturnValueOnce(true);
    useIsFocused.mockReturnValueOnce(true);
    const { unmount } = renderHook(() => useBackButtonHandler(handlerSpy));
    unmount();

    BackHandler.mockPressBack();

    expect(handlerSpy).not.toHaveBeenCalled();
    expect(BackHandler.exitApp).toHaveBeenCalledTimes(1);
  });
});
