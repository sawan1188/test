import { normalizeAmount } from '@components/commons/normalizers';
import { normalizeContactNumber } from '../normalizers';

describe('normalizeAmount', () => {
  it('should return value if value is empty', () => {
    const value = '';
    const normalizedAmount = normalizeAmount(value);
    expect(normalizedAmount).toBe(value);
  });

  it('should return value if value is undefined', () => {
    const value = undefined;
    const normalizedAmount = normalizeAmount(value);
    expect(normalizedAmount).toBe(value);
  });

  it('should return two decimal places', () => {
    const value = '1234.456';
    const normalizedAmount = normalizeAmount(value);
    expect(normalizedAmount).toBe('1234.45');
  });

  it('should return two decimal places after the first decimal point', () => {
    const value = '1234.456.789';
    const normalizedAmount = normalizeAmount(value);
    expect(normalizedAmount).toBe('1234.45');
  });

  it('should return previous value when there is no match', () => {
    const previousValue = '1234.45';
    const value = 'abc';
    const normalizedAmount = normalizeAmount(value, previousValue);
    expect(normalizedAmount).toBe('1234.45');
  });

  it('should return twenty character length value', () => {
    const value = '123456789012345678901234';
    const normalizedAmount = normalizeAmount(value);
    expect(normalizedAmount).toBe('12345678901234567890');
  });
});

describe('normalizeContactNumber', () => {
  it('should handle null values', () => {
    const result = normalizeContactNumber(null);
    expect(result).toBe(null);
  });

  it('should limit max characters to 16', () => {
    const value = '1234567891234567';
    const result = normalizeContactNumber(value);
    expect(result.length).toBe(16);
  });

  it('should only accept numbers', () => {
    const value = '12345678.';
    const result = normalizeContactNumber(value);
    expect(result).toBe('12345678');
  });

  it('should handle non digits mid string', () => {
    const value = '123456.78';
    const result = normalizeContactNumber(value);
    expect(result).toBe('12345678');
  });

  it('should handle plus symbol', () => {
    const value = '+123456.78';
    const result = normalizeContactNumber(value);
    expect(result).toBe('+12345678');
  });
});
