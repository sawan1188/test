import React from 'react';
import { View } from 'react-native';
import { render } from 'react-native-testing-library';
import { setRefs, runValidations } from '../utils';

describe('setRefs', () => {
  it('should return a setRef function that assigns instance to all the element in the input array', () => {
    let refFnValue;
    const refObject = React.createRef();
    const refFn = value => (refFnValue = value);

    const setRef = setRefs(refObject, refFn, null);
    render(<View ref={setRef} />);
    expect(refFnValue).toBeTruthy();
    expect(refObject.current).toBeTruthy();
  });
});

describe('runValidations', () => {
  it('should run validations', () => {
    const hasValue = value => value && (value.trim ? value.trim() : true);

    const validateRequired = value => (hasValue(value) ? '' : 'isRequired');

    const validateEmail = value =>
      /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
        ? ''
        : 'invalidEmail';
    const validations = [validateRequired, validateEmail];
    expect(runValidations(validations)('test@test.com')).toBe('');
    expect(runValidations(validations)('test123')).toBe('invalidEmail');
    expect(runValidations(validations)('')).toBe('isRequired');
  });
});
