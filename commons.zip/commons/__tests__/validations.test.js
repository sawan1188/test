import {
  hasValue,
  validateRequired,
  validateContactNumber,
  validateClaimType,
  validateClaimReason,
  validateConsultationDate,
  validateMultiSelectCheckBox,
  validateHeight,
  validateWeight,
  validateWaistCircumference,
  validateEmailWithMessageId,
  validateRequiredWithMessageId,
  validateContactNumberWithMessageId,
  validateNameWithMessageId,
  validateAgeWithMessageId,
  validateContactNumberLength,
  validateSingleSelectCheckBox,
} from '../validations';

describe('hasValue', () => {
  it('should return false for empty string', () => {
    const value = '  ';
    const result = hasValue(value);
    expect(result).toBeFalsy();
  });

  it('should return true for a non empty string', () => {
    const value = ' a ';
    const result = hasValue(value);
    expect(result).toBeTruthy();
  });
});

describe('validateRequired', () => {
  it('should return empty string for non empty value', () => {
    const value = ' a ';
    const result = validateRequired(value);
    expect(result).toEqual('');
  });

  it('should return isRequired for an empty value', () => {
    const value = '  ';
    const result = validateRequired(value);
    expect(result).toEqual('isRequired');
  });
});

describe('validateContactNumber', () => {
  it('should return empty when there are only numeric characters', () => {
    expect(validateContactNumber('123')).toBe('');
  });

  it('should return empty when there are numeric characters and a + sign', () => {
    expect(validateContactNumber('+123')).toBe('');
  });

  it('should return invalidContactNumber when there is non numeric character apart from a + sign', () => {
    expect(validateContactNumber('123a')).toBe('invalidContactNumber');
  });

  it('should return invalidContactNumber when there are numeric characters and a + sign', () => {
    expect(validateContactNumber('123+')).toBe('invalidContactNumber');
  });

  it('should return invalidContactNumber when there are numeric characters and extra + sign', () => {
    expect(validateContactNumber('123++')).toBe('invalidContactNumber');
  });

  it('should return invalidContactNumber when it is just + sign', () => {
    expect(validateContactNumber('+')).toBe('invalidContactNumber');
  });
});

describe('validateContactNumberLength', () => {
  it('should return invalidContactNumberLength', () => {
    expect(validateContactNumberLength('12345678909876543223456789')).toBe(
      'invalidContactNumberLength',
    );
  });

  it('should return empty when contact number is valid', () => {
    expect(validateContactNumberLength()).toBe('');
    expect(validateContactNumberLength('123')).toBe('');
    expect(validateContactNumberLength('+234567891234567')).toBe('');
  });
});

describe('validateClaimType', () => {
  it('should return empty string for non empty value', () => {
    const value = ' a ';
    const result = validateClaimType(value);
    expect(result).toEqual('');
  });

  it('should return claimTypeRequired for an empty value', () => {
    const value = '  ';
    const result = validateClaimType(value);
    expect(result).toEqual('claimTypeRequired');
  });
});

describe('validateClaimReason', () => {
  it('should return empty string for non empty value', () => {
    const value = ' a ';
    const result = validateClaimReason(value);
    expect(result).toEqual('');
  });

  it('should return claimReasonRequired for an empty value', () => {
    const value = '  ';
    const result = validateClaimReason(value);
    expect(result).toEqual('claimReasonRequired');
  });
});

describe('validateConsultationDate', () => {
  it('should return empty string for non empty value', () => {
    const value = ' a ';
    const result = validateConsultationDate(value);
    expect(result).toEqual('');
  });

  it('should return consultationDateRequired for an empty value', () => {
    const value = '  ';
    const result = validateConsultationDate(value);
    expect(result).toEqual('consultationDateRequired');
  });
});

describe('validateMultiSelectCheckBox', () => {
  it('should return empty string for non empty array value', () => {
    const value = ['item1'];
    const result = validateMultiSelectCheckBox(value);
    expect(result).toEqual('');
  });

  it('should return selectRequired for empty array value', () => {
    const value = [];
    const result = validateMultiSelectCheckBox(value);
    expect(result).toEqual('selectRequired');
  });

  it('should return selectRequired if value is undefined', () => {
    const value = undefined;
    const result = validateMultiSelectCheckBox(value);
    expect(result).toEqual('selectRequired');
  });
});

describe('validateSingleSelectCheckBox', () => {
  it('should return empty string for non empty array value', () => {
    const value = ['item1'];
    const result = validateSingleSelectCheckBox(value);
    expect(result).toEqual('');
  });

  it('should return selectRequired for empty array value', () => {
    const value = [];
    const result = validateSingleSelectCheckBox(value);
    expect(result).toEqual('selectRequired');
  });

  it('should return selectRequired if value is undefined', () => {
    const value = undefined;
    const result = validateSingleSelectCheckBox(value);
    expect(result).toEqual('selectRequired');
  });
});

describe('validateHeight', () => {
  it('should return empty string for non empty value', () => {
    const value = '123';
    const result = validateHeight(value);
    expect(result).toEqual('');
  });

  it('should return invalidHeight for an empty value', () => {
    const value = '  ';
    const result = validateHeight(value);
    expect(result).toEqual('invalidHeight');
  });

  it('should return invalidHeight for a value less than 50', () => {
    const value = '49';
    const result = validateHeight(value);
    expect(result).toEqual('invalidHeight');
  });

  it('should return invalidHeight for a value more than 300', () => {
    const value = '301';
    const result = validateHeight(value);
    expect(result).toEqual('invalidHeight');
  });

  it('should return invalidHeight for a value that is not a number', () => {
    const value = 'twenty';
    const result = validateHeight(value);
    expect(result).toEqual('invalidHeight');
  });
});

describe('validateWeight', () => {
  it('should return empty string for non empty value', () => {
    const value = '123';
    const result = validateWeight(value);
    expect(result).toEqual('');
  });

  it('should return invalidWeight for an empty value', () => {
    const value = '  ';
    const result = validateWeight(value);
    expect(result).toEqual('invalidWeight');
  });

  it('should return invalidWeight for a value less than 30', () => {
    const value = '29';
    const result = validateWeight(value);
    expect(result).toEqual('invalidWeight');
  });

  it('should return invalidWeight for a value more than 650', () => {
    const value = '651';
    const result = validateWeight(value);
    expect(result).toEqual('invalidWeight');
  });

  it('should return invalidWeight for a value that is not a number', () => {
    const value = 'fifty';
    const result = validateWeight(value);
    expect(result).toEqual('invalidWeight');
  });
});

describe('validateWaistCircumference', () => {
  it('should return empty string for non empty value', () => {
    const value = '123';
    const result = validateWaistCircumference(value);
    expect(result).toEqual('');
  });

  it('should return empty string for an empty value since it is an optional field', () => {
    const value = '  ';
    const result = validateWaistCircumference(value);
    expect(result).toEqual('');
  });

  it('should return invalidWaistCircumference for a value less than 40', () => {
    const value = '39';
    const result = validateWaistCircumference(value);
    expect(result).toEqual('invalidWaistCircumference');
  });

  it('should return invalidWaistCircumference for a value more than 300', () => {
    const value = '301';
    const result = validateWaistCircumference(value);
    expect(result).toEqual('invalidWaistCircumference');
  });

  it('should return invalidWaistCircumference for a value that is not a number', () => {
    const value = 'one hundred';
    const result = validateWaistCircumference(value);
    expect(result).toEqual('invalidWaistCircumference');
  });
});

describe('validateRequiredWithMessageId', () => {
  test('should return empty string for non empty value', () => {
    const value = '1';
    const result = validateRequiredWithMessageId({ value });
    expect(result).toEqual('');
  });

  test('should return messageId string for  empty value and have messageId', () => {
    const value = '';
    const messageId = 'messageId';
    const result = validateRequiredWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);
  });
  test('should return default messageId string for  empty value and dont have messageId', () => {
    const value = '';
    const result = validateRequiredWithMessageId({ value });
    expect(result).toEqual('isRequired');
  });
});

describe('validateEmailWithMessageId', () => {
  test('should return empty string for valid email', () => {
    const value = 'valid@e.co';
    let result = validateEmailWithMessageId({ value });
    expect(result).toEqual('');
  });

  test('should return messageId string for  (empty value or invalid email )   and have messageId', () => {
    let value = '';
    const messageId = 'messageId';
    let result = validateEmailWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);

    value = 'invalidEmail';
    result = validateEmailWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);
  });

  test('should return default messageId string for  (empty value or invalid email ) and dont have messageId', () => {
    let value = '';
    let result = validateEmailWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.emailError');

    value = 'invalidEmail';
    result = validateEmailWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.emailError');
  });
});

describe('validateContactNumberWithMessageId', () => {
  test('should return empty string for valid contact number', () => {
    const value = '01';
    let result = validateContactNumberWithMessageId({ value });
    expect(result).toEqual('');
  });

  test('should return messageId string for  (empty value or invalid value )   and have messageId', () => {
    let value = '';
    const messageId = 'messageId';
    let result = validateContactNumberWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);

    value = 'invalidNumber';
    result = validateContactNumberWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);
  });

  test('should return default messageId string for  (empty value or invalid value ) and dont have messageId', () => {
    let value = '';
    let result = validateContactNumberWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.contactNumberError');

    value = 'invalidEmail';
    result = validateContactNumberWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.contactNumberError');
  });
});

describe('validateNameWithMessageId', () => {
  test('should return empty string for valid Name', () => {
    const value = 'Name';
    let result = validateNameWithMessageId({ value });
    expect(result).toEqual('');
  });

  test('should return messageId string for  empty value  and have messageId', () => {
    let value = '';
    const messageId = 'messageId';
    let result = validateNameWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);
  });

  test('should return default messageId string for  invalid value and dont have messageId', () => {
    let value = '';
    let result = validateNameWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.nameError');
  });

  test('should be invalid name if length more than max length and less than min length', () => {
    let value = 'four';
    let result = validateNameWithMessageId({ value, min: 5, max: 10 });
    expect(result).toEqual('signUp.signUpForm.nameError');
    value = 'fourfivesixseven';
    result = validateNameWithMessageId({ value, min: 5, max: 10 });
    expect(result).toEqual('signUp.signUpForm.nameError');
  });
});

describe('validateAgeWithMessageId', () => {
  test('should return empty string for valid Age', () => {
    let value = '1970-01-01T00:00:00.000Z';
    let result = validateAgeWithMessageId({ value });
    expect(result).toEqual('');
    value = '01-01-1993';
    result = validateAgeWithMessageId({ value });
    expect(result).toEqual('');
  });

  test('should return messageId string for  empty value  and have messageId', () => {
    let value = 'invalidTime';
    const messageId = 'messageId';
    let result = validateAgeWithMessageId({ value, messageId });
    expect(result).toEqual(messageId);
  });

  test('should return default messageId string for  invalid value and dont have messageId', () => {
    let value = 'invalidTime';
    let result = validateAgeWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.dateOfBirthNotEnoughAgeError');
  });

  test('should be invalid name if time less than minAge', () => {
    let value = '01-01-20010';
    let result = validateAgeWithMessageId({ value, minAge: 18 });
    expect(result).toEqual('signUp.signUpForm.dateOfBirthNotEnoughAgeError');
  });

  test('should be invalid name if time less than minAge default 16', () => {
    let value = '01-01-2005';
    let result = validateAgeWithMessageId({ value });
    expect(result).toEqual('signUp.signUpForm.dateOfBirthNotEnoughAgeError');

    value = '01-01-2004';
    result = validateAgeWithMessageId({ value });
    expect(result).toEqual('');
  });
});
