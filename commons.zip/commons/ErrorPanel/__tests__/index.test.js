import { render } from '@testUtils';
import React from 'react';
import ErrorPanel from '../index';
import errorImage from '../images/errorPanel.png';

jest.mock('@utils', () => {
  return {
    ...require.requireActual('@utils'),
  };
});

describe('ErrorPanel', () => {
  const [Screen] = render(
    <ErrorPanel
      image={errorImage}
      heading="Error"
      description="Something went wrong"
      showGoBack
    />,
  );

  it('should render errorpanel with image and message from props', () => {
    expect(Screen.getByText('Error')).toBeDefined();
    expect(Screen.getByText('Something went wrong')).toBeDefined();
  });
});
