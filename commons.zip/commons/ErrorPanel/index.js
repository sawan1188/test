import { Image, StatusPanel } from '@components/commons';
import errorImage from './images/errorPanel.png';
import React from 'react';
import { Button } from '@components/commons';
import { useIntl } from '@components/commons/hooks';
import { useNavigation } from '@react-navigation/native';

const ErrorPanel = ({ image, heading, description, showGoBack }) => {
  const { goBack } = useNavigation();
  const intl = useIntl();
  const messageImage = image ?? errorImage;
  const messageHeading =
    heading ?? intl.formatMessage({ id: 'errorPanel.title' });
  const messageDescription =
    description ?? intl.formatMessage({ id: 'errorPanel.message' });

  return (
    <StatusPanel
      image={<Image source={messageImage} />}
      heading={messageHeading}
      description={messageDescription}
      actions={
        showGoBack && (
          <Button
            primary
            title={intl.formatMessage({
              id: 'goBack',
            })}
            onPress={goBack}
          />
        )
      }
    />
  );
};

export default ErrorPanel;
