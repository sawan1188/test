import { useContext, useEffect, useLayoutEffect, useState } from 'react';
import { BackHandler } from 'react-native';
import { ThemeContext } from 'styled-components/native';
import { useMemoOne, useCallbackOne } from 'use-memo-one';
import { useIsFocused } from '@react-navigation/native';
import { IntlContext } from './IntlContext';

export function useTheme() {
  const theme = useContext(ThemeContext);
  return theme || {};
}

export function useIntl() {
  return useContext(IntlContext);
}

export function useFetchActions(
  fetchActions = [],
  shouldFetch = true,
  dependencies = [],
  parameters = [],
) {
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  useEffect(() => {
    let mounted = true;
    if (shouldFetch) {
      const doFetch = async () => {
        try {
          if (mounted) {
            setIsError(false);
            setIsLoading(true);
          }
          await Promise.all(
            fetchActions.map((fn, index) => fn(parameters[index])),
          );
        } catch (e) {
          if (mounted) {
            setIsError(true);
          }
        } finally {
          if (mounted) {
            setIsLoading(false);
          }
        }
      };
      doFetch();
    }
    return () => {
      mounted = false;
    };
  }, [...fetchActions, shouldFetch, ...dependencies]);

  return [isLoading, isError];
}

export function useBackButtonHandler(handler) {
  const isFocused = useIsFocused();
  useLayoutEffect(() => {
    if (isFocused) {
      BackHandler.addEventListener('hardwareBackPress', handler);
    }
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', handler);
    };
  }, [isFocused, handler]);
}

export { useMemoOne, useCallbackOne };
