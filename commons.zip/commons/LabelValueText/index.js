import React from 'react';
import { is } from 'ramda';
import { Box, Text, SecondaryText } from '@components/commons';

const LabelValueText = ({ label, children }) => {
  return (
    <>
      <SecondaryText>{label}</SecondaryText>
      {React.Children.map(children, x => (
        <Box mt={1}>{is(String, x) ? <Text>{x}</Text> : x}</Box>
      ))}
    </>
  );
};

export default LabelValueText;
