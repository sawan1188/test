import React from 'react';
import { ScrollView } from 'react-native';
import { Box, ScreenHeadingText, Text } from '@components/commons';

const StatusPanel = ({
  image,
  heading,
  subHeading,
  subHeadingProps,
  description,
  disclaimer,
  actions,
}) => (
  <ScrollView centerContent>
    <Box display="flex" p={4} alignItems="center">
      <Box>{image}</Box>
      <Box mt={4}>
        <Box>
          <ScreenHeadingText textAlign="center">{heading}</ScreenHeadingText>
          {subHeading && (
            <Box>
              <Text color="gray.3" textAlign="center" {...subHeadingProps}>
                {subHeading}
              </Text>
            </Box>
          )}
        </Box>
        <Box mt={3}>
          <Text textAlign="center">{description}</Text>
        </Box>
        {disclaimer && (
          <Box mt={3}>
            <Text textAlign="center">{disclaimer}</Text>
          </Box>
        )}
      </Box>
      {actions && (
        <Box width="100%" mt={4}>
          {actions}
        </Box>
      )}
    </Box>
  </ScrollView>
);

export default StatusPanel;
