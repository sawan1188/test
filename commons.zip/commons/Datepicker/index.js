/* istanbul ignore file */
import React, { useState, forwardRef, useImperativeHandle } from 'react';
import PropTypes from 'prop-types';
import DateTimePicker from 'react-native-modal-datetime-picker';
import { View } from 'react-native';
import { Appearance } from 'react-native-appearance';

const Datepicker = (
  { field, defaultDate, onConfirm, onCancel, ...props },
  ref,
) => {
  const [date, setDate] = useState(defaultDate);
  const [isVisible, setIsVisible] = useState(false);
  const colorScheme = Appearance.getColorScheme();

  useImperativeHandle(ref, () => ({
    setIsVisible: visible => {
      setIsVisible(visible);
    },
  }));
  return (
    <View>
      {field({ date, setIsVisible })}
      <DateTimePicker
        isDarkModeEnabled={colorScheme === 'dark'}
        date={date}
        isVisible={isVisible}
        onConfirm={newDate => {
          setIsVisible(!isVisible);
          setDate(newDate);
          onConfirm && onConfirm(newDate);
        }}
        onCancel={() => {
          setIsVisible(!isVisible);
          if (onCancel) {
            onCancel();
          }
        }}
        {...props}
      />
    </View>
  );
};

Datepicker.propTypes = {
  field: PropTypes.func.isRequired,
  defaultDate: PropTypes.instanceOf(Date),
  onCancel: PropTypes.func,
};

export default forwardRef(Datepicker);
