import {
  alignItems,
  alignContent,
  justifyContent,
  flexWrap,
  flexBasis,
  height,
  flexDirection,
  space,
  paddingTop,
  paddingBottom,
  marginBottom,
  borderRadius,
} from 'styled-system';
import { Box } from '@components/commons';
import styled from 'styled-components/native';

// Follow https://css-tricks.com/snippets/css/a-guide-to-flexbox/ for container

const Flex = styled(Box)`
    display: flex;
    flex-wrap: wrap;
    ${alignItems}
    ${alignContent}
    ${justifyContent}
    ${flexWrap}
    ${flexBasis}
    ${flexDirection}
    ${height}
    ${space}
    ${paddingTop}
    ${paddingBottom}
    ${marginBottom}
    ${borderRadius}
`;

export default Flex;
