import React from 'react';
import { Text } from '@components/commons';
import styled, { withTheme } from 'styled-components/native';

const LabelWrapper = styled(Text)`
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 4;
  line-height: 18px;
  font-size: 16px;
  ${({ theme }) => `
    color: ${theme.inputField.inputBorder}
    background-color: ${theme.backgroundColor.default}
  `};
`;

const LabelRequired = styled(Text)`
  ${({ theme }) => `
  color: ${theme.colors.error[0]}
`}
`;

const InputLabel = ({ children, labelStyle, required }) => {
  return (
    <LabelWrapper style={labelStyle}>
      {children} {children && required && <LabelRequired>*</LabelRequired>}
    </LabelWrapper>
  );
};
export default withTheme(InputLabel);
