import { renderForTest } from '@testUtils';
import InputLabel from '../index';
import React from 'react';
import theme from '@theme';

const props = {
  theme,
};

describe('InputLabel', () => {
  it('renders correctly', () => {
    const component = renderForTest(<InputLabel {...props} />);
    // expect(component.toJSON()).toMatchSnapshot();
  });
});
