const DEFAULT_PASSWORD_VALIDATION = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
const DEFAULT_PHONE_VALIDATION = /^\d{1,}$/;
const DEFAULT_EMAIL_VALIDATION = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

const defaultNameValidation = ({ value, min, max }) =>
  hasValue(value) && withinMinAndMax(value.length, min || 1, max || 50);

export const hasValue = value => value && (value.trim ? value.trim() : true);

export const validateRequired = value => (hasValue(value) ? '' : 'isRequired');

const withinMinAndMax = (value, min, max) => value >= min && value <= max;

export const validateRequiredCompanyName = value =>
  validateRequired(value) && 'invalidCompanyName';

export const validatePassword = value =>
  validateRequired(value) && 'invalidPassword';

export const validateContactNumber = value =>
  /^([0|\+]?[0-9])?([0-9]{0,16})$/.test(value) ? '' : 'invalidContactNumber';

export const validateContactNumberLength = value => {
  if (value) return value.length <= 16 ? '' : 'invalidContactNumberLength';
  return '';
};

export const validateEmail = value =>
  /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value) ? '' : 'invalidEmail';

export const validateCompanyCharacters = value =>
  /[_.]/.test(value) ? 'invalidCompanyCharacters' : '';

export const validateHeight = value =>
  withinMinAndMax(value, 50, 300) ? '' : 'invalidHeight';

export const validateWeight = value =>
  withinMinAndMax(value, 30, 650) ? '' : 'invalidWeight';

export const validateWaistCircumference = value =>
  hasValue(value) &&
  (withinMinAndMax(value, 40, 300) ? '' : 'invalidWaistCircumference');

export const validateClaimType = value =>
  hasValue(value) ? '' : 'claimTypeRequired';

export const validateClaimReason = value =>
  hasValue(value) ? '' : 'claimReasonRequired';

export const validateDiagnosisText = value =>
  hasValue(value) ? '' : 'diagnosisTextRequired';

export const validateConsultationDate = value =>
  hasValue(value) ? '' : 'consultationDateRequired';

export const validateMultiSelectCheckBox = value =>
  value && value.length > 0 ? '' : 'selectRequired';

export const validateSingleSelectCheckBox = value =>
  value && value.length > 0 ? '' : 'selectRequired';

export const validateEmailWithMessageId = ({ value, messageId, regex }) =>
  (regex || DEFAULT_EMAIL_VALIDATION)?.test(value)
    ? ''
    : messageId || 'signUp.signUpForm.emailError';

export const validateRequiredWithMessageId = ({ value, messageId }) =>
  hasValue(value) ? '' : messageId || 'isRequired';

export const validateContactNumberWithMessageId = ({
  value,
  messageId,
  regex,
}) =>
  (regex || DEFAULT_PHONE_VALIDATION)?.test(value)
    ? ''
    : messageId || 'signUp.signUpForm.contactNumberError';

export const validatePasswordWithMessageId = ({ value, messageId, regex }) => {
  return (regex || DEFAULT_PASSWORD_VALIDATION)?.test(value)
    ? ''
    : messageId || 'signUp.signUpForm.passwordError';
};

export const validateNameWithMessageId = ({
  value,
  min,
  max,
  messageId,
  regex,
}) => {
  return regex?.test(value) || defaultNameValidation({ value, min, max })
    ? ''
    : messageId || 'signUp.signUpForm.nameError';
};

export const validateAgeWithMessageId = ({ value, minAge = 16, messageId }) => {
  const pickedDate = new Date(value);
  const minDate = new Date();
  minDate.setFullYear(minDate.getFullYear() - minAge);
  return pickedDate.getTime() <= minDate.getTime()
    ? ''
    : messageId || 'signUp.signUpForm.dateOfBirthNotEnoughAgeError';
};
