/* istanbul ignore file */
import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { space, color, height, flex } from 'styled-system';
import { wrapScrollView } from 'react-native-scroll-into-view';
import { Platform, Keyboard, ScrollView } from 'react-native';

const ScrollIntoViewScrollView = wrapScrollView(ScrollView);

const StyledScrollView = styled.View`
  ${({ theme }) => `
    background-color: ${theme.backgroundColor.default}
  `}
  ${space}
  ${color}
  ${height}
  ${flex}
`;

const CustomScrollView = React.forwardRef(({ children, ...restProps }, ref) => {
  return (
    <StyledScrollView flex={1} {...restProps}>
      <ScrollIntoViewScrollView
        ref={ref}
        keyboardDismissMode="on-drag"
        keyboardShouldPersistTaps="handled"
        onScrollBeginDrag={Platform.OS === 'android' ? Keyboard.dismiss : null}
      >
        {children}
      </ScrollIntoViewScrollView>
    </StyledScrollView>
  );
});

CustomScrollView.propTypes = {
  children: PropTypes.node,
};

export default CustomScrollView;
