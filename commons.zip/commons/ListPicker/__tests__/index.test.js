import { renderForTest } from '@testUtils';
import React from 'react';
import { ListPicker } from '@components/commons';
import { fireEvent, flushMicrotasksQueue } from 'react-native-testing-library';
import { TouchableHighlight } from 'react-native';

describe('ListPicker', () => {
  it('renders correctly', () => {
    renderForTest(<ListPicker />);
  });

  it('should call the onPress handler', async () => {
    const data = [{ key: 'abc', value: 'abc' }];
    const onPressItem = jest.fn();
    const { getByType } = renderForTest(
      <ListPicker data={data} onPressItem={onPressItem} />,
    );

    const touchable = getByType(TouchableHighlight);
    fireEvent.press(touchable);
    await flushMicrotasksQueue();

    expect(onPressItem).toBeCalledWith('abc');
  });
});
