import { Text, Flex, Box, ScrollView } from '@components/commons';
import { Icon } from 'react-native-elements';
import React from 'react';
import PropTypes from 'prop-types';
import { FlatList, TouchableHighlight, View } from 'react-native';
import styled from 'styled-components/native';
import withTracking from '@components/commons/Tracking';

const ListItemContainer = styled(Flex)`
  ${({ theme }) => `
    background-color: ${theme.colors.gray[7]};
    border-bottom-color: #e1e1e1;
  `}
  padding-top: 18;
  padding-bottom: 18;
  padding-left: 32;
  padding-right: 32;
  border-bottom-width: 1;
`;

const CheckContainer = styled(View)`
  padding-left: 8px;
`;

const IconContainer = styled(View)`
  padding-right: 18px;
`;

const ListItem = ({ value, onPress, selected, icon }) => {
  return (
    <TouchableHighlight onPress={onPress} underlayColor="#AAA">
      <ListItemContainer
        flexDirection="row"
        justifyContent="space-between"
        alignItems="center"
      >
        {icon && (
          <IconContainer>
            <Icon size={24} color="#646464" name={icon} />
          </IconContainer>
        )}
        <Box flex={1}>
          <Text
            color="gray.1"
            fontSize={16}
            lineHeight={24}
            letterSpacing={0.15}
          >
            {value}
          </Text>
        </Box>
        {selected && (
          <CheckContainer>
            <Icon size={24} name="check" />
          </CheckContainer>
        )}
      </ListItemContainer>
    </TouchableHighlight>
  );
};

ListItem.propTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.node]).isRequired,
  onPress: PropTypes.func,
  selected: PropTypes.bool,
  icon: PropTypes.string,
};

const TrackedListItem = withTracking(ListItem);

const ListPicker = ({
  data,
  onPressItem,
  selectedKey,
  icon,
  header,
  getActionParams,
}) => {
  return (
    <ScrollView flex={!header && 1} bg="gray.7">
      {header && (
        <Box pl={4} pt={4}>
          <Text fontWeight="bold">{header}</Text>
        </Box>
      )}
      <FlatList
        data={data}
        ListFooterComponent={<Box pb={24} />}
        keyExtractor={item => {
          return item.key && item.key.toString();
        }}
        renderItem={({ item }) => (
          <TrackedListItem
            key={item.key}
            value={item.value}
            onPress={() => onPressItem(item.key)}
            selected={selectedKey === item.key}
            icon={icon}
            accessibilityLabel={item.value}
            actionParams={getActionParams ? getActionParams(item) : null}
          />
        )}
      />
    </ScrollView>
  );
};

ListPicker.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      value: PropTypes.oneOfType([PropTypes.string, PropTypes.node]).isRequired,
    }),
  ),
  onPressItem: PropTypes.func,
  selectedKey: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  icon: PropTypes.string,
  header: PropTypes.node,
};

export default ListPicker;
