/* eslint-disable react-native/no-inline-styles*/
/* istanbul ignore file */
import React from 'react';
import PropTypes from 'prop-types';
import { Card, Box, Image, Pdf } from '@components/commons';
import styled from 'styled-components/native';
import { Icon } from 'react-native-elements';
import { TouchableHighlight, View } from 'react-native';
import { useTheme, useIntl } from '@components/commons/hooks';

const PDF_CONTENT = 'application/pdf';
const AddButtonCard = props => <Card backgroundColor="white" {...props} />;
const EmptyCard = props => (
  <Box
    backgroundColor="backgroundColor"
    borderRadius={2}
    border="2px solid rgba(0, 0, 0, 0.05)"
    {...props}
  />
);

const ImageStyled = styled(Image)`
  border-radius: 4px;
`;

const StyledTouchableHighlight = styled(TouchableHighlight)`
  border-radius: 4px;
`;

const InnerContainer = styled(View)`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
`;

const UploadBox = ({
  accessibilityDocumentType,
  accessibilityField,
  disabled,
  onAdd,
  onView,
  data,
  width,
  height,
}) => {
  const theme = useTheme();
  const intl = useIntl();
  const accessibilityLabelValues = {
    documentType: accessibilityDocumentType,
    field: accessibilityField,
  };

  if (data) {
    const isPdf =
      data.type === PDF_CONTENT ||
      data.uri.startsWith('data:application/pdf;base64,');

    return (
      <View>
        <Card width={width} height={height} backgroundColor="white">
          <Box
            height={height}
            width={width}
            alignItem="center"
            justifyContent="center"
            borderRadius="4px"
          >
            {isPdf ? (
              <Pdf
                secure={data.secure}
                source={{ uri: data.uri, cache: false }}
                enablePaging={false}
                pointerEvents="none"
                spacing={0}
                fitPolicy={0}
                style={{
                  backgroundColor: '#fff',
                  borderRadius: 4,
                  height,
                  flex: 1,
                }}
                enableAnnotationRendering={false}
                onError={error => {
                  console.log(error);
                }}
              />
            ) : (
              <ImageStyled
                secure={data.secure}
                source={{ uri: data.uri }}
                height={height}
              />
            )}
          </Box>
          <StyledTouchableHighlight
            underlayColor={theme.colors.touchableOverlayColor}
            delayPressIn={0}
            disabled={disabled}
            onPress={onView}
            accessibilityLabel={intl.formatMessage(
              {
                id: 'uploadBox.accessibilityLabel.view',
              },
              accessibilityLabelValues,
            )}
            style={{
              position: 'absolute',
              zIndex: 2,
              left: 0,
              right: 0,
              bottom: 0,
              top: 0,
              opacity: 0.5,
            }}
          >
            <View />
          </StyledTouchableHighlight>
        </Card>
      </View>
    );
  }

  if (onAdd) {
    return (
      <AddButtonCard height={height} width={width}>
        <StyledTouchableHighlight
          underlayColor={theme.colors.touchableOverlayColor}
          delayPressIn={0}
          disabled={disabled}
          onPress={onAdd}
          accessibilityLabel={intl.formatMessage(
            {
              id: 'uploadBox.accessibilityLabel.add',
            },
            accessibilityLabelValues,
          )}
        >
          <InnerContainer>
            <Icon color={theme.colors.gray[1]} name="add" size={26} />
          </InnerContainer>
        </StyledTouchableHighlight>
      </AddButtonCard>
    );
  }

  return (
    <EmptyCard
      width={width}
      height={height}
      accessible
      accessibilityLabel={intl.formatMessage(
        {
          id: 'uploadBox.accessibilityLabel.emptySlot',
        },
        accessibilityLabelValues,
      )}
    >
      <InnerContainer>
        <Icon color={theme.colors.gray[5]} name="add" size={26} />
      </InnerContainer>
    </EmptyCard>
  );
};

UploadBox.propTypes = {
  disabled: PropTypes.bool,
  theme: PropTypes.shape({}),
  onAdd: PropTypes.oneOfType([PropTypes.func, PropTypes.bool]),
  onView: PropTypes.func,
  data: PropTypes.shape({ uri: PropTypes.string, type: PropTypes.string }),
  width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  height: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  accessibilityDocumentType: PropTypes.string.isRequired,
  accessibilityField: PropTypes.string.isRequired,
};

UploadBox.defaultProps = {
  height: 176,
  width: 128,
};

export default UploadBox;
