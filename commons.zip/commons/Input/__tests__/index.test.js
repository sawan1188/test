import React from 'react';
import { renderForTest } from '@testUtils';
import { Input as ReactElementsInput } from 'react-native-elements';
import { act, fireEvent } from 'react-native-testing-library';
import Input from '../index';

describe('Input', () => {
  test('Render input with error', () => {
    const input = renderForTest(
      <Input
        value="Test Value"
        onChangeText={jest.fn()}
        label="My Label"
        error="My Error"
        touched
      />,
    );

    act(() => {
      fireEvent(input.getByType(ReactElementsInput), 'blur');
    });

    const inputJSON = input.toJSON();

    // expect(inputJSON).toMatchSnapshot();
  });

  // test('Render focused on input with label ', () => {
  //   const input = renderForTest(
  //     <Input
  //       value="Test Value"
  //       onChangeText={() => jest.fn()}
  //       label="My Label"
  //     />,
  //   );

  //   act(() => {
  //     fireEvent.press(input.getByType(TouchableOpacity));
  //   });

  //   const inputJSON = input.toJSON();

  //   expect(inputJSON).toMatchSnapshot();
  // });

  test('Render focused on input without label ', () => {
    const input = renderForTest(
      <Input
        value="Test Value"
        onChangeText={() => jest.fn()}
        label="My Label"
      />,
    );

    act(() => {
      fireEvent(input.getByType(ReactElementsInput), 'focus');
    });

    const inputJSON = input.toJSON();

    // expect(inputJSON).toMatchSnapshot();
  });

  test('Render with focus callback when onFocus invoked', () => {
    const onFocusHandler = jest.fn();
    const input = renderForTest(
      <Input value="Test Value" onFocus={onFocusHandler} label="My Label" />,
    );

    act(() => {
      fireEvent(input.getByType(ReactElementsInput), 'focus');
    });

    expect(onFocusHandler).toHaveBeenCalled();
  });

  test('Render with blur callback when onBlur invoked', () => {
    const onBlurHandler = jest.fn();
    const input = renderForTest(
      <Input value="Test Value" onBlur={onBlurHandler} label="My Label" />,
    );

    act(() => {
      fireEvent(input.getByType(ReactElementsInput), 'blur');
    });

    expect(onBlurHandler).toHaveBeenCalled();
  });
});
