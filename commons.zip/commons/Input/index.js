import React, { useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Input as ReactElementsInput, Icon } from 'react-native-elements';
import styled, { withTheme } from 'styled-components/native';
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  Platform,
} from 'react-native';
import theme from '@theme';
import Box from '../Box';
import { setRefs } from '../utils';

const styles = StyleSheet.create({
  inputContainerStyle: {
    borderWidth: 1,
    borderColor: theme.inputField.inputBorderUntouched,
    paddingLeft: 16,
    paddingRight: 16,
    borderRadius: 4,
    position: 'absolute',
  },
  inputContainerFocused: {
    borderColor: theme.inputField.inputFocus,
    borderWidth: 2,
    borderBottomWidth: 2,
  },
  error: {
    borderColor: theme.colors.error[0],
    borderWidth: 2,
    borderBottomWidth: 2,
  },
  errorLabel: {
    color: theme.colors.error[0],
  },
  inputStyle: {
    height: 56,
  },
  containerStyle: {
    paddingLeft: 0,
    paddingRight: 0,
  },
  label: {
    color: theme.inputField.inputText,
    left: 16,
    top: 18,
    paddingLeft: 3,
    paddingRight: 3,
    backgroundColor: theme.backgroundColor.default,
    borderRadius: 4,
    fontSize: 18,
  },
  blue: {
    color: theme.inputField.inputFocus,
  },
  labelTop: {
    color: theme.inputField.inputBorder,
    fontSize: 12,
    top: -7,
    left: 16,
    paddingLeft: 3,
    paddingRight: 3,
    backgroundColor: theme.backgroundColor.default,
    borderRadius: 4,
  },
  labelView: {
    display: 'flex',
    flexDirection: 'row',
  },
  errorMessage: {
    top: 60,
    left: 16,
    color: theme.colors.error[0],
    position: 'absolute',
  },
  labelOpacity: {
    zIndex: 1000,
  },
  touchOpacity: {
    zIndex: 1001,
  },
  leftIconContainerStyle: {
    marginLeft: 0,
  },
  rightIconContainerStyle: {},
});

const HintText = styled.Text`
  margin: 4px;
  position: absolute;
  top: 60;
  left: 16;
  font-size: 12px;
  ${({ hintTextLeft }) => {
    if (hintTextLeft !== undefined) return `left: ${hintTextLeft}`;
  }}
  ${({ theme, focused }) => {
    if (focused) return `color: ${theme.inputField.inputFocus}`;
    return `color: ${theme.colors.gray[1]}`;
  }}
  ${({ customHintStyles }) => {
    if (customHintStyles) return customHintStyles;
  }}
`;

const Input = React.forwardRef((props, ref) => {
  const {
    value,
    error,
    onBlur,
    onFocus,
    label,
    secureTextEntry,
    theme,
    hint,
    touched,
    returnKeyType,
    labelComponent,
    hintTextLeft,
    customStyles = {},
    secureIconComponent,
    placeholderTextColor = '#3c3c434c',
  } = props;

  const inputRef = useRef(ref);

  const [focused, setFocused] = useState(false);
  const [visiblePassword, setVisiblePassword] = useState(!secureTextEntry);

  const errorMessage = touched && error;

  const eyeballColor =
    (errorMessage && theme.colors.error[0]) ||
    (focused && theme.colors.blue[0]) ||
    (touched && '#000000') ||
    '#b8b8b8';

  const labelStyle = () => {
    const hasValue = !!value;
    const customLabelStyles = customStyles.customLabelStyles;
    const customFocusedLabelStyles = customStyles.customLabelStyles;
    const layoutStyle = focused || hasValue ? styles.labelTop : styles.label;
    const highlightStyle = () => {
      if (errorMessage) {
        return hasValue || focused ? styles.errorLabel : {};
      }
      return focused ? customFocusedLabelStyles || styles.blue : {};
    };
    return { ...layoutStyle, ...customLabelStyles, ...highlightStyle() };
  };

  const labelCom = labelComponent || (
    <TouchableOpacity
      activeOpacity={1}
      style={styles.labelOpacity}
      onPress={() => {
        inputRef.current.focus();
      }}
    >
      <View style={styles.labelView}>
        <Text style={labelStyle()}>{label}</Text>
      </View>
    </TouchableOpacity>
  );

  const valueAsString =
    typeof value !== 'undefined' && value !== null ? value.toString() : value;

  const inputContainerStyle = [
    styles.inputContainerStyle,
    customStyles.inputContainerStyle,
  ];
  const inputContainerFocused = [
    styles.inputContainerFocused,
    customStyles.inputContainerFocused,
  ];
  const errorStyle = [styles.error, customStyles.error];

  const secureIconCom = secureIconComponent ? (
    secureIconComponent(setVisiblePassword, visiblePassword, eyeballColor)
  ) : (
    <Icon
      onPress={() => {
        setVisiblePassword(!visiblePassword);
      }}
      name={visiblePassword ? 'visibility' : 'visibility-off'}
      type="material"
      color={eyeballColor}
    />
  );

  return (
    <Box height={100}>
      <ReactElementsInput
        {...props}
        {...(Platform.OS === 'android'
          ? { selectionColor: theme.colors.blue[1] }
          : {})}
        inputContainerStyle={[
          inputContainerStyle,
          focused && inputContainerFocused,
          errorMessage && errorStyle,
        ]}
        returnKeyType={returnKeyType || 'default'}
        containerStyle={styles.containerStyle}
        inputStyle={[styles.inputStyle, customStyles.inputStyle]}
        label={label && labelCom}
        errorMessage={errorMessage || ''}
        errorStyle={[styles.errorMessage, customStyles.errorMessage]}
        leftIconContainerStyle={styles.leftIconContainerStyle}
        onBlur={e => {
          if (onBlur) onBlur(e);
          setFocused(false);
        }}
        ref={setRefs(inputRef, ref)}
        onFocus={e => {
          if (onFocus) onFocus(e);
          setFocused(true);
        }}
        secureTextEntry={!visiblePassword}
        placeholderTextColor={placeholderTextColor} // default placeholder color, force for darktheme as well
        {...(secureTextEntry
          ? {
              rightIcon: secureIconCom,
              rightIconContainerStyle: [
                styles.rightIconContainerStyle,
                customStyles.rightIconContainerStyle,
              ],
            }
          : {})}
        value={valueAsString}
      />
      {!errorMessage && (
        <HintText
          focused={focused}
          hintTextLeft={hintTextLeft}
          customHintStyles={customStyles.customHintStyles}
        >
          {hint}
        </HintText>
      )}
    </Box>
  );
});

Input.propTypes = {
  label: PropTypes.string,
  error: PropTypes.string,
  onBlur: PropTypes.func,
  onFocus: PropTypes.func,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  hint: PropTypes.string,
  secureTextEntry: PropTypes.bool,
  theme: PropTypes.shape({}),
  touched: PropTypes.bool,
  returnKeyType: PropTypes.string,
  editable: PropTypes.bool,
  onTouchStart: PropTypes.func,
  customStyles: PropTypes.shape({
    customLabelStyles: PropTypes.object,
    customFocusedLabelStyles: PropTypes.object,
    customHintStyles: PropTypes.object,
    inputContainerStyle: PropTypes.object,
    inputContainerFocused: PropTypes.object,
    error: PropTypes.object,
    inputStyle: PropTypes.object,
    errorMessage: PropTypes.object,
    rightIconContainerStyle: PropTypes.object,
  }),
};

export default withTheme(Input);
