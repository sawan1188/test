import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { space, color, height, flex } from 'styled-system';
import { wrapScrollViewConfigured } from 'react-native-scroll-into-view';
import { Platform, Keyboard } from 'react-native';

const ScrollIntoViewScrollView = wrapScrollViewConfigured({
  refPropName: 'innerRef',
})(KeyboardAwareScrollView);

const StyledScrollView = styled.KeyboardAvoidingView`
  ${({ theme }) => `
    background-color: ${theme.backgroundColor.default}
  `}
  ${space}
  ${color}
  ${height}
  ${flex}
`;

const CustomScrollView = ({
  children,
  contentContainerStyle,
  ...restProps
}) => {
  return (
    <StyledScrollView flex={1} {...restProps}>
      <ScrollIntoViewScrollView
        scrollIndicatorInsets={{ right: 1 }} 
        keyboardDismissMode="on-drag"
        keyboardShouldPersistTaps="handled"
        onScrollBeginDrag={Platform.OS === 'android' ? Keyboard.dismiss : null}
        contentContainerStyle={contentContainerStyle}
      >
        {children}
      </ScrollIntoViewScrollView>
    </StyledScrollView>
  );
};

CustomScrollView.propTypes = {
  children: PropTypes.node,
};

export default CustomScrollView;
