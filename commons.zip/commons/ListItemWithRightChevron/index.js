import React from 'react';
import { ListItem, Image } from '@components/commons';
import angleRight from './images/angleRight.png';

const ListItemWithRightChevron = ({
  icImage = angleRight,
  children,
  ...props
}) => {
  return (
    <ListItem {...props} rightIcon={<Image source={icImage} size={30} />}>
      {children}
    </ListItem>
  );
};

export default ListItemWithRightChevron;
