import React from 'react';
import { renderForTest } from '@testUtils';
import { ListItem, Image, Text } from '@components/commons';
import ListItemWithRightChevron from '../';
import angleRight from '../images/angleRight.png';

describe('ListItemWithRightChevron', () => {
  let getListItem = component => component.queryAllByType(ListItem);
  let renderComponent = ({ children, props }) => {
    if (!children) children = <></>;
    return renderForTest(
      <ListItemWithRightChevron {...props}>
        {children}
      </ListItemWithRightChevron>,
    );
  };
  it('should render a ListItem', () => {
    const item = renderComponent({});

    expect(getListItem(item)).toHaveLength(1);
  });
  it('should render a right chevron', () => {
    const item = renderComponent({});
    const listItem = getListItem(item)[0];

    expect(listItem.props.rightIcon.type).toBe(Image);
    expect(listItem.props.rightIcon.props.source).toBe(angleRight);
  });
  it('should render children as ListItem children', () => {
    const children = <Text>Some Text</Text>;
    const item = renderComponent({ children });
    const listItem = getListItem(item)[0];

    expect(listItem.props.children).toBe(children);
  });
  it('should pass all props to ListItem', () => {
    var props = {
      prop1: 'value1',
      prop2: 'value2',
    };
    const item = renderComponent({ props });
    const listItem = getListItem(item)[0];

    expect(listItem.props).toEqual(expect.objectContaining(props));
  });
});
