import React from 'react';
import PropTypes from 'prop-types';
import { injectIntl, intlShape } from 'react-intl';

/**
 * This is a temporary workaround to enable useIntl hook.
 * Replace this with actual Context from react-intl
 */
const IntlContext = React.createContext(null);

const BaseIntlContextProvider = ({ intl, children }) => (
  <IntlContext.Provider value={intl}>{children}</IntlContext.Provider>
);
BaseIntlContextProvider.propTypes = {
  intl: intlShape.isRequired,
  children: PropTypes.node.isRequired,
};

const IntlContextProvider = injectIntl(BaseIntlContextProvider);

export { IntlContext, IntlContextProvider };
